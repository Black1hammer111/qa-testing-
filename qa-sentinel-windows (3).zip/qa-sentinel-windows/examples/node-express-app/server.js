const express = require("express");
const { exec } = require("child_process");
const crypto = require("crypto");
const _ = require("lodash");

const app = express();
const JWT_SECRET = "my-hardcoded-jwt-secret";

app.get("/search", (req, res) => {
  const q = req.query.q;
  db.query(`SELECT * FROM products WHERE name LIKE '%${q}%'`, (err, rows) => res.json(rows));
});

app.get("/convert", (req, res) => {
  exec("convert " + req.query.file + " out.png", (err, stdout) => res.send(stdout));
});

app.get("/hello", (req, res) => {
  res.send("<h1>Hello " + req.query.name + "</h1>");
});

app.get("/download", (req, res) => {
  res.sendFile(req.query.path);
});

app.post("/merge", (req, res) => {
  const settings = _.merge({}, JSON.parse(req.body));
  res.json(settings);
});

function makeResetToken() {
  return Math.random().toString(36).slice(2);
}

function checksum(data) {
  return crypto.createHash("md5").update(data).digest("hex");
}

function isEmpty(value) {
  try {
    return value.length == 0;
  } catch (e) {}
}

app.listen(3000, "0.0.0.0");
