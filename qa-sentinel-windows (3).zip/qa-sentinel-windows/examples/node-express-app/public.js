function showMessage(msg) {
  document.getElementById("out").innerHTML = msg;
}
function run(code) {
  return eval(code);
}
