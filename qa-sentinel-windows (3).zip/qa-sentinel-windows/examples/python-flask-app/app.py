import os
import pickle
import sqlite3

import yaml
from flask import Flask, request

app = Flask(__name__)
app.config["SECRET_KEY"] = "s3cr3t-pr0d-k3y-123"
AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE"
DATABASE_URL = "postgres://admin:SuperSecret99@db.internal:5432/shop"


@app.route("/user")
def get_user():
    user_id = request.args.get("id")
    conn = sqlite3.connect("app.db")
    rows = conn.execute("SELECT * FROM users WHERE id = '" + user_id + "'").fetchall()
    return str(rows)


@app.route("/calc")
def calc():
    return str(eval(request.args.get("expr")))


@app.route("/ping")
def ping():
    host = request.args.get("host")
    os.system("ping -c 1 " + host)
    return "ok"


@app.route("/import", methods=["POST"])
def import_data():
    data = pickle.loads(request.data)
    cfg = yaml.load(request.form["config"])
    return {"items": len(data), "cfg": cfg}


@app.route("/file")
def read_file():
    with open(request.args.get("name")) as fh:
        return fh.read()


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True)
