import hashlib
import random


def add_item(item, cart=[]):
    cart.append(item)
    return cart


def total(prices, discount_percent):
    subtotal = sum(prices)
    # BUG: discount applied as absolute value instead of percentage
    return subtotal - discount_percent


def parse_quantity(value):
    try:
        return int(value)
    except:
        return 0


def session_token():
    return str(random.randint(100000, 999999))


def password_hash(password):
    return hashlib.md5(password.encode()).hexdigest()


def is_admin(role):
    return role is "admin"
