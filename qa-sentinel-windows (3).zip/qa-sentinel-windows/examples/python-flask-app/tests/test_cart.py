from cart import add_item, parse_quantity, total


def test_total_applies_percentage_discount():
    assert total([50, 50], 10) == 90


def test_total_with_large_discount():
    assert total([200], 50) == 100


def test_parse_quantity():
    assert parse_quantity("3") == 3


def test_add_item_returns_fresh_cart():
    add_item("apple")
    assert add_item("pear") == ["pear"]
