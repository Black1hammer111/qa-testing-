import java.security.MessageDigest;
import java.sql.*;

public class UserDao {
    private static final String DB_PASSWORD = "Pr0dPassw0rd!";

    public ResultSet find(Connection c, String name) throws Exception {
        Statement st = c.createStatement();
        return st.executeQuery("SELECT * FROM users WHERE name = '" + name + "'");
    }

    public boolean isAdmin(String role) {
        return role == "admin";
    }

    public void backup(String dir) throws Exception {
        Runtime.getRuntime().exec("tar czf backup.tgz " + dir);
    }

    public byte[] hash(String s) throws Exception {
        return MessageDigest.getInstance("MD5").digest(s.getBytes());
    }

    public void load(String path) {
        try {
            new java.io.FileInputStream(path).close();
        } catch (Exception e) {}
    }
}
