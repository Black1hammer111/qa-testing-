resource "aws_s3_bucket" "assets" {
  bucket = "company-assets"
  acl    = "public-read"
}

resource "aws_security_group" "db" {
  ingress {
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
