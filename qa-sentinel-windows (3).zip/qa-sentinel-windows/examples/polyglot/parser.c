#include <stdio.h>
#include <string.h>

void greet(const char *name) {
    char buf[16];
    strcpy(buf, name);
    printf("Hello %s\n", buf);
}

int main(void) {
    char line[32];
    gets(line);
    greet(line);
    return 0;
}
