#!/bin/bash
curl -fsSL https://get.example.com/install.sh | sudo bash
chmod 777 /var/www
rm -rf $TARGET_DIR/
cd $1
