package main

import (
	"crypto/md5"
	"crypto/tls"
	"fmt"
	"net/http"
	"os/exec"
)

func fetch(url string) {
	tr := &http.Transport{TLSClientConfig: &tls.Config{InsecureSkipVerify: true}}
	client := &http.Client{Transport: tr}
	_, _ = client.Get(url)
}

func run(arg string) {
	_ = exec.Command("sh", "-c", "ls "+arg).Run()
	fmt.Printf("%x\n", md5.Sum([]byte(arg)))
}
