from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass, field

SEVERITIES = ["critical", "high", "medium", "low", "info"]
SEVERITY_RANK = {s: len(SEVERITIES) - i for i, s in enumerate(SEVERITIES)}
SEVERITY_WEIGHT = {"critical": 15, "high": 6, "medium": 2, "low": 0.5, "info": 0}

CATEGORIES = {
    "security": "Security vulnerability",
    "secret": "Leaked secret / credential",  # nosec B105 (category label)
    "dependency": "Vulnerable dependency",
    "bug": "Probable bug",
    "test": "Failing test",
    "config": "Insecure configuration",
    "quality": "Code quality",
}

_SEVERITY_ALIASES = {
    "error": "high",
    "warning": "medium",
    "warn": "medium",
    "note": "low",
    "information": "info",
    "informational": "info",
    "moderate": "medium",
    "style": "info",
    "unknown": "medium",
}


def normalize_severity(value: str | None, default: str = "medium") -> str:
    if not value:
        return default
    v = str(value).strip().lower()
    if v in SEVERITY_RANK:
        return v
    return _SEVERITY_ALIASES.get(v, default)


def severity_from_cvss(score: float | None) -> str:
    if score is None:
        return "medium"
    if score >= 9.0:
        return "critical"
    if score >= 7.0:
        return "high"
    if score >= 4.0:
        return "medium"
    if score > 0:
        return "low"
    return "info"


@dataclass
class Finding:
    title: str
    severity: str
    category: str
    scanner: str
    rule_id: str
    file: str = ""
    line: int = 0
    description: str = ""
    recommendation: str = ""
    snippet: str = ""
    cwe: str = ""
    references: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.severity = normalize_severity(self.severity)
        if self.category not in CATEGORIES:
            self.category = "quality"

    @property
    def fingerprint(self) -> str:
        raw = f"{self.rule_id}|{self.file}|{self.line}|{self.snippet.strip()}"
        return hashlib.sha256(raw.encode("utf-8", "replace")).hexdigest()[:16]

    @property
    def location(self) -> str:
        if not self.file:
            return ""
        return f"{self.file}:{self.line}" if self.line else self.file

    def to_dict(self) -> dict:
        d = asdict(self)
        d["fingerprint"] = self.fingerprint
        d["location"] = self.location
        return d


@dataclass
class ScannerResult:
    name: str
    status: str  # ok | skipped | error | not_applicable
    message: str = ""
    duration: float = 0.0
    findings: list[Finding] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "status": self.status,
            "message": self.message,
            "duration": round(self.duration, 2),
            "findings": len(self.findings),
        }
