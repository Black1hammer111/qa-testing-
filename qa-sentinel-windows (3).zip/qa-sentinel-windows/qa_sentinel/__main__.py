from qa_sentinel.cli import main

raise SystemExit(main())
