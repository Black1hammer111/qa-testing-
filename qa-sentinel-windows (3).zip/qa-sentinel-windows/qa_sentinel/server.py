"""Local web backend: upload a file, folder or archive and get a bilingual (EN/AR) report.

Uses only the standard library. Uploaded code is never executed: the project's own
test suite is always skipped for uploads.
"""
from __future__ import annotations

import json
import re
import tarfile
import tempfile
import threading
import uuid
import webbrowser
import zipfile
from email.parser import BytesParser
from email.policy import default as default_policy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib import resources  # requires Python >= 3.9; nosemgrep
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse

from qa_sentinel import __version__
from qa_sentinel.i18n import translations_for
from qa_sentinel.project import Project
from qa_sentinel.reports import write_reports
from qa_sentinel.runner import run_scan
from qa_sentinel.scanners import all_scanners

MAX_UPLOAD = 200 * 1024 * 1024
MAX_EXTRACTED = 1024 * 1024 * 1024
MAX_FILES = 50_000
ARCHIVE_SUFFIXES = (".zip", ".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tar.xz")
REPORT_FORMATS = {"html": ("report.html", "text/html; charset=utf-8"),
                  "json": ("report.json", "application/json"),
                  "sarif": ("report.sarif", "application/sarif+json"),
                  "md": ("report.md", "text/markdown; charset=utf-8")}
REPORT_ID = re.compile(r"^[0-9a-f]{16}$")


class UploadError(ValueError):
    pass


def safe_name(name: str, fallback: str = "upload") -> str:
    name = re.sub(r"[^\w.\- ]", "_", name).strip(" ").rstrip(".")
    return name[:120] or fallback


def safe_relpath(raw: str) -> PurePosixPath | None:
    parts = [safe_name(p, "") for p in raw.replace("\\", "/").split("/")]
    parts = [p for p in parts if p and p not in (".", "..")]
    return PurePosixPath(*parts) if parts else None


def _inside(dest: Path, rel: PurePosixPath) -> Path:
    target = (dest / rel).resolve()
    if target != dest and dest not in target.parents:
        raise UploadError(f"unsafe path in upload: {rel}")
    return target


class _Budget:
    def __init__(self) -> None:
        self.bytes = 0
        self.files = 0

    def add_file(self) -> None:
        self.files += 1
        if self.files > MAX_FILES:
            raise UploadError(f"too many files (limit {MAX_FILES})")

    def add_bytes(self, n: int) -> None:
        self.bytes += n
        if self.bytes > MAX_EXTRACTED:
            raise UploadError(f"extracted content exceeds {MAX_EXTRACTED // (1024 * 1024)} MB")


def _copy_limited(src, target: Path, budget: _Budget) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    with open(target, "wb") as out:
        while True:
            chunk = src.read(1024 * 1024)
            if not chunk:
                break
            budget.add_bytes(len(chunk))
            out.write(chunk)


def extract_zip(archive: Path, dest: Path, budget: _Budget) -> None:
    try:
        zf = zipfile.ZipFile(archive)
    except zipfile.BadZipFile as exc:
        raise UploadError(f"invalid zip file: {exc}") from exc
    with zf:
        for info in zf.infolist():
            if info.is_dir() or (info.external_attr >> 16) & 0o170000 == 0o120000:
                continue
            rel = safe_relpath(info.filename)
            if rel is None:
                continue
            budget.add_file()
            with zf.open(info) as src:
                _copy_limited(src, _inside(dest, rel), budget)


def extract_tar(archive: Path, dest: Path, budget: _Budget) -> None:
    try:
        tf = tarfile.open(archive)
    except tarfile.TarError as exc:
        raise UploadError(f"invalid tar archive: {exc}") from exc
    with tf:
        for member in tf:
            if not member.isfile():
                continue
            rel = safe_relpath(member.name)
            if rel is None:
                continue
            budget.add_file()
            src = tf.extractfile(member)
            if src is not None:
                with src:
                    _copy_limited(src, _inside(dest, rel), budget)


def is_archive(name: str) -> bool:
    return name.lower().endswith(ARCHIVE_SUFFIXES)


def project_name(files: list[tuple[str, bytes]]) -> str:
    first = files[0][0].replace("\\", "/")
    if len(files) > 1 and "/" in first:
        return safe_name(first.split("/")[0], "project")
    base = first.rsplit("/", 1)[-1]
    for suffix in sorted(ARCHIVE_SUFFIXES, key=len, reverse=True):
        if base.lower().endswith(suffix):
            return safe_name(base[: -len(suffix)], "project")
    return safe_name(base.rsplit(".", 1)[0] if "." in base else base, "project")


def materialize(files: list[tuple[str, bytes]], workdir: Path) -> Path:
    """Write uploaded files into workdir/<name>/, extracting archives. Returns the project root."""
    if not files:
        raise UploadError("no file uploaded")
    root = workdir / project_name(files)
    root.mkdir(parents=True)
    root = root.resolve()
    folder_upload = len(files) > 1 and "/" in files[0][0].replace("\\", "/")
    budget = _Budget()
    for raw_name, data in files:
        rel = safe_relpath(raw_name)
        if rel is None:
            continue
        if folder_upload and len(rel.parts) > 1:
            rel = PurePosixPath(*rel.parts[1:])
        if is_archive(rel.name) and not folder_upload:
            archive = workdir / ("upload-" + uuid.uuid4().hex + "-" + rel.name)
            archive.write_bytes(data)
            (extract_zip if rel.name.lower().endswith(".zip") else extract_tar)(archive, root, budget)
            archive.unlink()
            continue
        budget.add_file()
        budget.add_bytes(len(data))
        target = _inside(root, rel)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    if budget.files == 0:
        raise UploadError("the upload contained no files")
    # An archive that wraps everything in one folder: scan from that folder so paths and
    # the project's .qa-sentinel.json resolve the same way as the CLI and the standalone page.
    entries = list(root.iterdir())
    if len(entries) == 1 and entries[0].is_dir() and not entries[0].is_symlink():
        root = entries[0]
    return root


def parse_multipart(content_type: str, body: bytes) -> tuple[list[tuple[str, bytes]], dict[str, str]]:
    if not content_type.lower().startswith("multipart/form-data"):
        raise UploadError("expected multipart/form-data")
    msg = BytesParser(policy=default_policy).parsebytes(
        b"MIME-Version: 1.0\r\nContent-Type: " + content_type.encode("latin-1") + b"\r\n\r\n" + body)
    files, fields = [], {}
    for part in msg.iter_parts():
        name = part.get_param("name", header="content-disposition")
        filename = part.get_filename()
        payload = part.get_payload(decode=True) or b""
        if filename is not None:
            if filename or payload:
                files.append((filename or "upload", payload))
        elif name:
            fields[name] = payload.decode("utf-8", "replace")
    return files, fields


class ScanService:
    def __init__(self, reports_dir: Path | None = None, max_parallel: int = 2) -> None:
        self.reports_dir = reports_dir or Path(tempfile.gettempdir()) / "qa-sentinel-web"
        self.reports_dir.mkdir(parents=True, exist_ok=True)
        self.slots = threading.Semaphore(max_parallel)

    def scan_upload(self, files: list[tuple[str, bytes]]) -> dict:
        with self.slots, tempfile.TemporaryDirectory(prefix="qas-upload-") as tmp:
            root = materialize(files, Path(tmp))
            project = Project.load(root)
            report = run_scan(project, skip=["tests"], jobs=4)
            report_id = uuid.uuid4().hex[:16]
            write_reports(report, self.reports_dir / report_id, list(REPORT_FORMATS))
            data = report.to_dict()
        return {
            "id": report_id, "project": data["project"], "summary": data["summary"],
            "scanners": data["scanners"], "duration_seconds": data["duration_seconds"],
            "top": [f for f in data["findings"] if f["severity"] in ("critical", "high")][:10],
            "ar": translations_for(data["findings"])["rules"],
            "report_url": f"/report/{report_id}",
            "downloads": {fmt: f"/report/{report_id}/{fmt}" for fmt in REPORT_FORMATS},
        }

    def report_file(self, report_id: str, fmt: str) -> Path | None:
        if not REPORT_ID.match(report_id) or fmt not in REPORT_FORMATS:
            return None
        path = self.reports_dir / report_id / REPORT_FORMATS[fmt][0]
        return path if path.is_file() else None


def scanner_status() -> list[dict]:
    return [{"name": s.name, "available": s.is_available(), "description": s.description,
             "install_hint": s.install_hint} for s in all_scanners() if s.name != "tests"]


def make_handler(service: ScanService):
    page = resources.files("qa_sentinel").joinpath("templates/upload.html").read_text(encoding="utf-8")
    page = page.replace("__VERSION__", __version__)

    class Handler(BaseHTTPRequestHandler):
        server_version = f"qa-sentinel/{__version__}"

        def log_message(self, fmt, *args):  # quieter console
            print(f"  {self.address_string()} {fmt % args}")

        def _send(self, status: int, body: bytes, ctype: str, extra: dict | None = None) -> None:
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def _json(self, status: int, obj) -> None:
            self._send(status, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

        def do_GET(self):
            path = urlparse(self.path).path
            if path in ("/", "/index.html"):
                return self._send(200, page.encode("utf-8"), "text/html; charset=utf-8")
            if path == "/api/scanners":
                return self._json(200, scanner_status())
            if path == "/api/health":
                return self._json(200, {"status": "ok", "version": __version__})
            m = re.match(r"^/report/([0-9a-f]+)(?:/(html|json|sarif|md))?/?$", path)
            if m:
                fmt = m.group(2) or "html"
                file = service.report_file(m.group(1), fmt)
                if file is None:
                    return self._json(404, {"error": "report not found"})
                extra = {} if m.group(2) is None else {
                    "Content-Disposition": f'attachment; filename="qa-{REPORT_FORMATS[fmt][0]}"'}
                return self._send(200, file.read_bytes(), REPORT_FORMATS[fmt][1], extra)
            self._json(404, {"error": "not found"})

        def do_POST(self):
            if urlparse(self.path).path != "/api/scan":
                return self._json(404, {"error": "not found"})
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                length = 0
            if length <= 0:
                return self._json(411, {"error": "empty upload"})
            if length > MAX_UPLOAD:
                return self._json(413, {"error": f"upload larger than {MAX_UPLOAD // (1024 * 1024)} MB"})
            body = self.rfile.read(length)
            try:
                files, _fields = parse_multipart(self.headers.get("Content-Type", ""), body)
                result = service.scan_upload(files)
            except UploadError as exc:
                return self._json(400, {"error": str(exc)})
            except Exception as exc:  # report, don't crash the server
                return self._json(500, {"error": f"{type(exc).__name__}: {exc}"[:400]})
            self._json(200, result)

    return Handler


def serve(host: str = "127.0.0.1", port: int = 8000, open_browser: bool = True) -> int:
    service = ScanService()
    httpd = ThreadingHTTPServer((host, port), make_handler(service))
    url = f"http://{'localhost' if host in ('127.0.0.1', '0.0.0.0', '') else host}:{port}/"  # display only. qa-sentinel: ignore  # nosec B104
    print(f"QA Sentinel {__version__} web UI running at {url}")
    print("  Press Ctrl+C to stop.")
    if open_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        httpd.server_close()
    return 0
