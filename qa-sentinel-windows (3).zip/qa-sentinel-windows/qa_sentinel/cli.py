from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from qa_sentinel import __version__
from qa_sentinel.models import SEVERITIES
from qa_sentinel.project import Project
from qa_sentinel.reports import FORMATS, write_reports
from qa_sentinel.runner import run_scan
from qa_sentinel.scanners import all_scanners

COLORS = {"critical": "\033[1;91m", "high": "\033[91m", "medium": "\033[93m", "low": "\033[96m", "info": "\033[37m",
          "ok": "\033[92m", "error": "\033[91m", "skipped": "\033[90m", "not_applicable": "\033[90m", "bold": "\033[1m"}
RESET = "\033[0m"

SAMPLE_CONFIG = {
    "exclude": ["docs/*", "*.generated.*"],
    "disable": [],
    "disable_rules": [],
    "ignore": [],
    "severity_overrides": {"QAS-CRY-003": "medium"},
    "fail_on": "high",
    "test_timeout": 900,
    "test_command": None,
    "junit_glob": None,
    "semgrep_configs": ["p/default"],
    "rules": [{
        "id": "CUSTOM-001",
        "title": "Use of deprecated internal API",
        "pattern": "legacy_client\\.",
        "languages": ["Python", "JavaScript"],
        "severity": "low",
        "category": "quality",
        "recommendation": "Migrate to new_client.",
    }],
}


def _c(key: str, text: str) -> str:
    if not sys.stdout.isatty() or os.environ.get("NO_COLOR"):
        return text
    return f"{COLORS.get(key, '')}{text}{RESET}"


def _csv(value: str | None) -> list[str]:
    return [v.strip() for v in (value or "").split(",") if v.strip()]


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="qa-sentinel", description="Language-agnostic QA, bug and security scanner.")
    p.add_argument("--version", action="version", version=f"qa-sentinel {__version__}")
    sub = p.add_subparsers(dest="command")

    s = sub.add_parser("scan", help="scan a project and generate reports")
    s.add_argument("path", nargs="?", default=".", help="project directory (default: .)")
    s.add_argument("-o", "--output", default=None, help="output directory (default: <path>/qa-report)")
    s.add_argument("-f", "--format", default="html,json,sarif,md", help=f"comma-separated: {','.join(FORMATS)}")
    s.add_argument("--fail-on", default=None, choices=SEVERITIES + ["none"],
                   help="exit with code 1 if a finding at or above this severity exists (default: high)")
    s.add_argument("--min-severity", default="info", choices=SEVERITIES, help="drop findings below this severity")
    s.add_argument("--only", help="comma-separated scanners to run")
    s.add_argument("--skip", help="comma-separated scanners to skip")
    s.add_argument("--no-tests", action="store_true", help="do not execute the project's test suite")
    s.add_argument("--exclude", action="append", default=[], help="glob to exclude (repeatable)")
    s.add_argument("--config", help="path to config JSON (default: <path>/.qa-sentinel.json)")
    s.add_argument("-j", "--jobs", type=int, default=4, help="scanners to run in parallel")
    s.add_argument("-q", "--quiet", action="store_true", help="only print the summary line")

    w = sub.add_parser("serve", help="start the web UI to upload and scan files (English/Arabic)")
    w.add_argument("--host", default="127.0.0.1", help="interface to bind (default: 127.0.0.1, local only)")
    w.add_argument("--port", type=int, default=8000, help="port (default: 8000)")
    w.add_argument("--no-browser", action="store_true", help="do not open a browser window")

    sub.add_parser("scanners", help="list scanners and whether they are installed")
    i = sub.add_parser("init", help="write a sample .qa-sentinel.json")
    i.add_argument("path", nargs="?", default=".")
    return p


def cmd_scanners() -> int:
    for s in all_scanners():
        status = _c("ok", "installed") if s.is_available() else _c("skipped", f"missing  -> {s.install_hint}")
        print(f"  {s.name:<14} {status:<20}  {s.description}")
    return 0


def cmd_init(path: str) -> int:
    target = Path(path) / ".qa-sentinel.json"
    if target.exists():
        print(f"{target} already exists", file=sys.stderr)
        return 2
    target.write_text(json.dumps(SAMPLE_CONFIG, indent=2) + "\n")
    print(f"Wrote {target}")
    return 0


def cmd_scan(args: argparse.Namespace) -> int:
    formats = _csv(args.format)
    bad = [f for f in formats if f not in FORMATS]
    if bad:
        print(f"Unknown format(s): {', '.join(bad)}", file=sys.stderr)
        return 2
    out_dir = Path(args.output) if args.output else Path(args.path) / "qa-report"
    excludes = list(args.exclude)
    try:
        out_rel = out_dir.resolve().relative_to(Path(args.path).resolve())
        excludes.append(out_rel.as_posix())
    except ValueError:
        pass
    project = Project.load(args.path, args.config, excludes)
    skip = _csv(args.skip) + (["tests"] if args.no_tests else [])

    if not args.quiet:
        langs = ", ".join(f"{k} ({v})" for k, v in project.languages.most_common(8)) or "none detected"
        print(_c("bold", f"QA Sentinel {__version__}") + f" scanning {project.root}")
        print(f"  {len(project.files)} files | languages: {langs}")
        if project.manifests:
            print(f"  package managers: {', '.join(sorted(project.manifests))}")

    def on_result(r):
        if not args.quiet:
            extra = f" ({r.message})" if r.message else ""
            print(f"  [{_c(r.status, r.status.replace('_', ' '))}] {r.name}: {len(r.findings)} findings in {r.duration:.1f}s{extra}")

    report = run_scan(project, _csv(args.only) or None, skip, args.jobs, args.min_severity, on_result)
    written = write_reports(report, out_dir, formats)

    counts = report.counts()
    summary = " ".join(_c(s, f"{counts[s]} {s}") for s in SEVERITIES)
    print(f"\nGrade {_c('bold', report.grade)} (score {report.score}/100) | {len(report.findings)} findings: {summary}")
    if not args.quiet:
        for f in report.findings[:10]:
            if f.severity in ("critical", "high"):
                print(f"  {_c(f.severity, f.severity.upper()):<10} {f.title}  {f.location}")
        for p in written:
            print(f"  report: {p}")
    fail_on = args.fail_on or project.config.get("fail_on", "high")
    return 1 if report.exceeds(fail_on) else 0


def _safe_console() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    if os.name == "nt":
        os.system("")  # enables ANSI colors in Windows 10+ consoles; constant argument. qa-sentinel: ignore  # nosec B605 B607


def main(argv: list[str] | None = None) -> int:
    _safe_console()
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] not in {"scan", "serve", "scanners", "init", "-h", "--help", "--version"}:
        argv.insert(0, "scan")
    if not argv:
        argv = ["scan"]
    args = build_parser().parse_args(argv)
    try:
        if args.command == "scanners":
            return cmd_scanners()
        if args.command == "init":
            return cmd_init(args.path)
        if args.command == "serve":
            from qa_sentinel.server import serve
            return serve(args.host, args.port, not args.no_browser)
        return cmd_scan(args)
    except (FileNotFoundError, NotADirectoryError, json.JSONDecodeError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
