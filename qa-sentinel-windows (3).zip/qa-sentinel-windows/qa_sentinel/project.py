from __future__ import annotations

import fnmatch
import json
import os
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

EXT_LANG = {
    ".py": "Python", ".pyw": "Python",
    ".js": "JavaScript", ".mjs": "JavaScript", ".cjs": "JavaScript", ".jsx": "JavaScript",
    ".ts": "TypeScript", ".tsx": "TypeScript",
    ".go": "Go", ".java": "Java", ".kt": "Kotlin", ".kts": "Kotlin", ".scala": "Scala",
    ".rb": "Ruby", ".php": "PHP", ".cs": "C#", ".vb": "VB.NET",
    ".c": "C", ".h": "C", ".cpp": "C++", ".cc": "C++", ".cxx": "C++", ".hpp": "C++", ".hh": "C++",
    ".rs": "Rust", ".swift": "Swift", ".m": "Objective-C", ".mm": "Objective-C",
    ".dart": "Dart", ".lua": "Lua", ".pl": "Perl", ".pm": "Perl", ".r": "R",
    ".ex": "Elixir", ".exs": "Elixir", ".erl": "Erlang", ".hs": "Haskell", ".clj": "Clojure",
    ".sh": "Shell", ".bash": "Shell", ".zsh": "Shell", ".ps1": "PowerShell",
    ".sql": "SQL", ".html": "HTML", ".htm": "HTML", ".vue": "Vue", ".svelte": "Svelte",
    ".yaml": "YAML", ".yml": "YAML", ".tf": "Terraform", ".hcl": "Terraform",
    ".xml": "XML", ".json": "JSON", ".toml": "TOML", ".ini": "INI", ".env": "Env",
    ".properties": "Properties", ".cfg": "INI", ".conf": "Config",
}
NAME_LANG = {
    "Dockerfile": "Dockerfile", "Containerfile": "Dockerfile", "Makefile": "Makefile",
    "Jenkinsfile": "Groovy", "Vagrantfile": "Ruby", "Gemfile": "Ruby", "Rakefile": "Ruby",
    ".env": "Env",
}
CODE_LANGUAGES_EXCLUDED_FROM_STATS = {"JSON", "XML", "TOML", "INI", "YAML", "Properties", "Config", "Env"}

MANIFESTS = {
    "package.json": "npm", "package-lock.json": "npm", "yarn.lock": "yarn", "pnpm-lock.yaml": "pnpm",
    "requirements.txt": "pip", "pyproject.toml": "python", "Pipfile": "pipenv", "Pipfile.lock": "pipenv",
    "poetry.lock": "poetry", "setup.py": "python",
    "go.mod": "go", "go.sum": "go", "Cargo.toml": "cargo", "Cargo.lock": "cargo",
    "pom.xml": "maven", "build.gradle": "gradle", "build.gradle.kts": "gradle",
    "Gemfile": "bundler", "Gemfile.lock": "bundler", "composer.json": "composer", "composer.lock": "composer",
    "pubspec.yaml": "pub", "mix.exs": "mix", "packages.config": "nuget",
}

DEFAULT_EXCLUDES = [
    ".git", ".hg", ".svn", "node_modules", "venv", ".venv", "env", "__pycache__", ".tox", ".nox",
    ".mypy_cache", ".pytest_cache", ".ruff_cache", "dist", "build", "target", "vendor", "bower_components",
    ".next", ".nuxt", ".gradle", ".idea", ".vscode", "coverage", ".terraform", "qa-report", "*.min.js",
    "*.map", "*.lock", "package-lock.json",
]

CONFIG_FILENAMES = (".qa-sentinel.json", "qa-sentinel.json")
MAX_FILE_BYTES = 1_000_000


def language_of(path: Path) -> str | None:
    if path.name in NAME_LANG:
        return NAME_LANG[path.name]
    if path.name.startswith("Dockerfile") or path.suffix == ".dockerfile":
        return "Dockerfile"
    if path.name.startswith(".env"):
        return "Env"
    return EXT_LANG.get(path.suffix.lower())


def is_test_file(rel: str) -> bool:
    p = rel.replace("\\", "/").lower()
    name = p.rsplit("/", 1)[-1]
    return (
        "/test/" in f"/{p}" or "/tests/" in f"/{p}" or "/__tests__/" in f"/{p}" or "/spec/" in f"/{p}"
        or name.startswith("test_") or name.endswith(("_test.py", "_test.go", ".test.js", ".test.ts",
                                                      ".spec.js", ".spec.ts", "test.java", "tests.cs"))
    )


def load_config(root: Path, explicit: str | None = None) -> dict:
    candidates = [Path(explicit)] if explicit else [root / n for n in CONFIG_FILENAMES]
    for c in candidates:
        if c.is_file():
            with open(c, encoding="utf-8") as fh:
                return json.load(fh)
    if explicit:
        raise FileNotFoundError(explicit)
    return {}


@dataclass
class Project:
    root: Path
    config: dict = field(default_factory=dict)
    extra_excludes: list[str] = field(default_factory=list)
    files: list[Path] = field(default_factory=list)
    languages: Counter = field(default_factory=Counter)
    manifests: dict[str, list[str]] = field(default_factory=dict)

    @classmethod
    def load(cls, root: str | Path, config_path: str | None = None, excludes: list[str] | None = None) -> "Project":
        root = Path(root).resolve()
        if not root.is_dir():
            raise NotADirectoryError(str(root))
        proj = cls(root=root, config=load_config(root, config_path), extra_excludes=list(excludes or []))
        proj._scan()
        return proj

    @property
    def excludes(self) -> list[str]:
        return DEFAULT_EXCLUDES + list(self.config.get("exclude", [])) + self.extra_excludes

    def is_excluded(self, rel: str) -> bool:
        parts = rel.replace("\\", "/").split("/")
        for pat in self.excludes:
            pat = pat.rstrip("/")
            if fnmatch.fnmatch(rel, pat) or any(fnmatch.fnmatch(p, pat) for p in parts):
                return True
        return False

    def rel(self, path: str | Path) -> str:
        p = Path(path)
        if not p.is_absolute():
            p = (self.root / p)
        try:
            return p.resolve().relative_to(self.root).as_posix()
        except ValueError:
            return Path(path).as_posix()

    def _scan(self) -> None:
        for dirpath, dirnames, filenames in os.walk(self.root):
            rel_dir = Path(dirpath).relative_to(self.root).as_posix()
            rel_dir = "" if rel_dir == "." else rel_dir
            dirnames[:] = [d for d in dirnames if not self.is_excluded(f"{rel_dir}/{d}".lstrip("/"))]
            for fn in filenames:
                rel = f"{rel_dir}/{fn}".lstrip("/")
                if fn in MANIFESTS:
                    self.manifests.setdefault(MANIFESTS[fn], []).append(rel)
                if self.is_excluded(rel):
                    continue
                path = Path(dirpath) / fn
                try:
                    if path.is_symlink() or path.stat().st_size > MAX_FILE_BYTES:
                        continue
                except OSError:
                    continue
                self.files.append(path)
                lang = language_of(path)
                if lang and lang not in CODE_LANGUAGES_EXCLUDED_FROM_STATS:
                    self.languages[lang] += 1

    def files_for(self, languages: set[str] | None) -> list[Path]:
        if languages is None:
            return list(self.files)
        return [f for f in self.files if language_of(f) in languages]

    def has(self, *languages: str) -> bool:
        return any(self.languages.get(lang) for lang in languages)
