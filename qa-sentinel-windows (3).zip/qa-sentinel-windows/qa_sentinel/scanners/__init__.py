from qa_sentinel.scanners.base import Scanner, ScannerSkipped
from qa_sentinel.scanners.builtin_rules import BuiltinRulesScanner
from qa_sentinel.scanners.external import (
    BanditScanner, GitleaksScanner, HadolintScanner, OsvScanner, SemgrepScanner, ShellcheckScanner,
)
from qa_sentinel.scanners.tests_runner import TestRunnerScanner


def all_scanners() -> list[Scanner]:
    return [
        BuiltinRulesScanner(), SemgrepScanner(), BanditScanner(), GitleaksScanner(), OsvScanner(),
        ShellcheckScanner(), HadolintScanner(), TestRunnerScanner(),
    ]


__all__ = ["Scanner", "ScannerSkipped", "all_scanners"]
