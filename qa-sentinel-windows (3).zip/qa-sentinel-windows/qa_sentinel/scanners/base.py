from __future__ import annotations

import os
import shutil
import subprocess  # nosec B404 (scanners are external CLI tools)
from pathlib import Path

from qa_sentinel.models import Finding
from qa_sentinel.project import Project


class ScannerSkipped(Exception):
    """Raised by a scanner when it decides at runtime it cannot run."""


class Scanner:
    name: str = ""
    description: str = ""
    binary: str | None = None
    install_hint: str = ""

    def is_available(self) -> bool:
        return self.binary is None or which(self.binary) is not None

    def is_applicable(self, project: Project) -> bool:
        return True

    def run(self, project: Project) -> list[Finding]:
        raise NotImplementedError


def which(binary: str) -> str | None:
    found = shutil.which(binary)
    if found:
        return found
    for extra in (Path.home() / ".local" / "bin", Path.home() / "go" / "bin", Path.home() / ".cargo" / "bin"):
        cand = extra / binary
        if cand.is_file() and os.access(cand, os.X_OK):
            return str(cand)
    return None


def run_cmd(cmd: list[str], cwd: Path | str, timeout: int = 900, env: dict | None = None) -> subprocess.CompletedProcess:
    exe = which(cmd[0]) or cmd[0]
    full_env = {**os.environ, **(env or {})}
    return subprocess.run(  # nosec B603 (argument list, no shell)
        [exe, *cmd[1:]], cwd=str(cwd), capture_output=True, text=True, timeout=timeout,
        env=full_env, errors="replace",
    )


def read_line(project: Project, rel: str, line: int) -> str:
    try:
        with open(project.root / rel, encoding="utf-8", errors="replace") as fh:
            for i, text in enumerate(fh, 1):
                if i == line:
                    return text.rstrip("\n")[:300]
    except OSError:
        pass
    return ""
