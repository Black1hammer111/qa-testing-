"""Runs the project's own test suite (any ecosystem) and converts failures into findings."""
from __future__ import annotations

import glob
import json
import re
import shlex
import sys
import tempfile
import xml.etree.ElementTree as ET  # local JUnit reports only; ElementTree never fetches external entities. qa-sentinel: ignore  # nosec B405
from dataclasses import dataclass
from pathlib import Path

from qa_sentinel.models import Finding
from qa_sentinel.project import Project
from qa_sentinel.scanners.base import Scanner, ScannerSkipped, which, run_cmd


@dataclass
class TestSuite:
    name: str
    cmd: list[str]
    cwd: Path
    junit_glob: str | None = None
    parser: str = "junit"  # junit | go | cargo | exitcode


def _has_pytest_tests(project: Project) -> bool:
    return any(re.match(r"test_.*\.py$|.*_test\.py$", f.name) for f in project.files)


def detect_suites(project: Project, tmp: Path) -> list[TestSuite]:
    root = project.root
    custom = project.config.get("test_command")
    if custom:
        cmd = shlex.split(custom) if isinstance(custom, str) else list(custom)
        return [TestSuite("custom", cmd, root, project.config.get("junit_glob"),
                          "junit" if project.config.get("junit_glob") else "exitcode")]
    suites: list[TestSuite] = []
    if project.has("Python") and _has_pytest_tests(project):
        junit = tmp / "pytest.xml"
        suites.append(TestSuite("pytest", [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider",
                                           f"--junitxml={junit}"], root, str(junit)))
    pkg = root / "package.json"
    if pkg.is_file():
        try:
            script = json.loads(pkg.read_text()).get("scripts", {}).get("test", "")
        except (json.JSONDecodeError, OSError):
            script = ""
        if script and "no test specified" not in script and which("npm"):
            if not (root / "node_modules").is_dir():
                raise ScannerSkipped("package.json has tests but node_modules is missing (run npm ci first)")
            suites.append(TestSuite("npm test", ["npm", "test", "--silent"], root, parser="exitcode"))
    if (root / "go.mod").is_file() and which("go"):
        suites.append(TestSuite("go test", ["go", "test", "./...", "-json"], root, parser="go"))
    if (root / "Cargo.toml").is_file() and which("cargo"):
        suites.append(TestSuite("cargo test", ["cargo", "test", "--no-fail-fast"], root, parser="cargo"))
    if (root / "pom.xml").is_file() and which("mvn"):
        suites.append(TestSuite("maven", ["mvn", "-q", "-B", "test", "-Dmaven.test.failure.ignore=true"], root,
                                str(root / "target/surefire-reports/*.xml")))
    gradlew = root / "gradlew"
    if gradlew.is_file() or ((root / "build.gradle").is_file() and which("gradle")):
        cmd = [str(gradlew)] if gradlew.is_file() else ["gradle"]
        suites.append(TestSuite("gradle", cmd + ["test", "--continue", "-q"], root,
                                str(root / "build/test-results/test/*.xml")))
    if list(root.glob("*.sln")) or list(root.glob("*.csproj")):
        if which("dotnet"):
            suites.append(TestSuite("dotnet test", ["dotnet", "test", "--logger", f"junit;LogFilePath={tmp}/dotnet.xml"],
                                    root, str(tmp / "dotnet.xml")))
    if (root / "Gemfile").is_file() and (root / "spec").is_dir() and which("bundle"):
        suites.append(TestSuite("rspec", ["bundle", "exec", "rspec"], root, parser="exitcode"))
    if (root / "composer.json").is_file() and (root / "vendor/bin/phpunit").is_file():
        suites.append(TestSuite("phpunit", ["vendor/bin/phpunit", f"--log-junit={tmp}/phpunit.xml"], root,
                                str(tmp / "phpunit.xml")))
    return suites


_PY_LOC = re.compile(r"^([\w./\\-]+\.(?:py|js|ts|java|kt|go|rb|php|cs|rs)):(\d+)", re.M)
_JAVA_LOC = re.compile(r"at [\w.$]+\((\w+\.(?:java|kt)):(\d+)\)")


def _locate(project: Project, text: str, classname: str) -> tuple[str, int]:
    for m in reversed(list(_PY_LOC.finditer(text))):
        rel = project.rel(m.group(1))
        if (project.root / rel).is_file():
            return rel, int(m.group(2))
    m = _JAVA_LOC.search(text)
    if m:
        hits = list(project.root.rglob(m.group(1)))
        if hits:
            return project.rel(hits[0]), int(m.group(2))
    if classname:
        cand = classname.replace(".", "/")
        for ext in (".py", ".java", ".kt", ".js", ".ts"):
            hits = [h for h in project.root.rglob(Path(cand).name + ext)]
            if hits:
                return project.rel(hits[0]), 0
    return "", 0


def _failure(project: Project, suite: str, name: str, message: str, details: str, classname: str = "") -> Finding:
    file, line = _locate(project, details or message, classname)
    return Finding(
        title=f"Failing test: {name}"[:160], severity="high", category="test", scanner=f"tests ({suite})",
        rule_id=f"test-failure/{suite}", file=file, line=line,
        description=(message or "Test failed.")[:600] + ("\n\n" + details[-1500:] if details else ""),
        recommendation="Reproduce locally with the test runner, fix the code under test (or the test if the expectation is wrong), and re-run.",
        snippet=(message or "")[:200],
    )


def parse_junit(project: Project, suite: str, pattern: str) -> list[Finding] | None:
    files = glob.glob(pattern)
    if not files:
        return None
    findings = []
    for f in files:
        try:
            tree = ET.parse(f)  # nosec B314 (locally generated JUnit report) nosemgrep
        except ET.ParseError:
            continue
        for case in tree.iter("testcase"):
            for tag in ("failure", "error"):
                node = case.find(tag)
                if node is not None:
                    cls = case.get("classname", "")
                    name = f"{cls}::{case.get('name')}" if cls else case.get("name", "?")
                    f_ = _failure(project, suite, name, node.get("message", ""), (node.text or "").strip(), cls)
                    if tag == "error":
                        f_.title = f_.title.replace("Failing test", "Test error")
                    findings.append(f_)
    return findings


def parse_go(project: Project, output: str) -> list[Finding]:
    logs: dict[tuple, list[str]] = {}
    findings = []
    for line in output.splitlines():
        try:
            ev = json.loads(line)
        except json.JSONDecodeError:
            continue
        key = (ev.get("Package"), ev.get("Test"))
        if ev.get("Action") == "output":
            logs.setdefault(key, []).append(ev.get("Output", ""))
        elif ev.get("Action") == "fail" and ev.get("Test"):
            text = "".join(logs.get(key, []))
            m = re.search(r"(\w+_test\.go):(\d+)", text)
            f = _failure(project, "go test", f"{ev['Package']}.{ev['Test']}", text.strip().splitlines()[-1] if text.strip() else "", text)
            if m:
                hits = list(project.root.rglob(m.group(1)))
                if hits:
                    f.file, f.line = project.rel(hits[0]), int(m.group(2))
            findings.append(f)
    return findings


def parse_cargo(project: Project, output: str) -> list[Finding]:
    findings = []
    for name in re.findall(r"^test (\S+) \.\.\. FAILED", output, re.M):
        block = re.search(rf"---- {re.escape(name)} stdout ----\n(.*?)(?=\n---- |\nfailures:)", output, re.S)
        text = block.group(1) if block else ""
        f = _failure(project, "cargo test", name, text.strip().splitlines()[0] if text.strip() else "", text)
        m = re.search(r"(src/[\w/]+\.rs|tests/[\w/]+\.rs):(\d+)", text)
        if m:
            f.file, f.line = m.group(1), int(m.group(2))
        findings.append(f)
    return findings


class TestRunnerScanner(Scanner):
    name = "tests"
    description = "Runs the project's test suite (pytest, npm, go, cargo, maven, gradle, dotnet, rspec, phpunit or custom)"

    def run(self, project: Project) -> list[Finding]:
        timeout = int(project.config.get("test_timeout", 900))
        findings: list[Finding] = []
        with tempfile.TemporaryDirectory() as tmp:
            suites = detect_suites(project, Path(tmp))
            if not suites:
                raise ScannerSkipped("no test suite detected")
            for suite in suites:
                if not which(suite.cmd[0]) and not Path(suite.cmd[0]).is_file():
                    continue
                try:
                    proc = run_cmd(suite.cmd, suite.cwd, timeout=timeout)
                except Exception as exc:  # timeout or spawn error
                    findings.append(_failure(project, suite.name, f"{suite.name} could not complete", str(exc), ""))
                    continue
                output = (proc.stdout or "") + "\n" + (proc.stderr or "")
                parsed = None
                if suite.parser == "junit" and suite.junit_glob:
                    parsed = parse_junit(project, suite.name, suite.junit_glob)
                elif suite.parser == "go":
                    parsed = parse_go(project, proc.stdout or "")
                elif suite.parser == "cargo":
                    parsed = parse_cargo(project, output)
                if parsed:
                    findings.extend(parsed)
                elif proc.returncode != 0:
                    findings.append(_failure(project, suite.name, f"{suite.name} exited with code {proc.returncode}",
                                             output.strip().splitlines()[-1] if output.strip() else "", output[-3000:]))
        return findings
