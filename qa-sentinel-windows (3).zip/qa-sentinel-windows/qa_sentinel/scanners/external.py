"""Adapters for best-in-class open-source scanners. Each is optional: if the tool
is not installed the scanner is skipped and reported as such."""
from __future__ import annotations

import json
import re
import tempfile
from pathlib import Path

from qa_sentinel.models import SEVERITY_RANK, Finding, normalize_severity, severity_from_cvss
from qa_sentinel.project import Project, is_test_file
from qa_sentinel.scanners.base import Scanner, ScannerSkipped, read_line, run_cmd


def _first_cwe(value) -> str:
    if not value:
        return ""
    items = value if isinstance(value, list) else [value]
    m = re.search(r"CWE-\d+", str(items[0]))
    return m.group(0) if m else ""


class SemgrepScanner(Scanner):
    name = "semgrep"
    binary = "semgrep"
    description = "Semgrep SAST: 30+ languages, community security & correctness rules"
    install_hint = "pip install semgrep"

    def run(self, project: Project) -> list[Finding]:
        configs = project.config.get("semgrep_configs", ["p/default"])
        cmd = ["semgrep", "scan", "--json", "--quiet", "--metrics=off", "--timeout", "30", "--disable-version-check"]
        for c in configs:
            cmd += ["--config", c]
        for ex in project.excludes:
            cmd += ["--exclude", ex]
        cmd.append(str(project.root))
        proc = run_cmd(cmd, project.root, timeout=int(project.config.get("semgrep_timeout", 900)))
        try:
            data = json.loads(proc.stdout or "{}")
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"semgrep produced invalid output: {proc.stderr.strip()[:300]}") from exc
        if proc.returncode not in (0, 1) and not data.get("results"):
            raise RuntimeError(proc.stderr.strip()[:300] or f"exit code {proc.returncode}")
        findings = []
        for r in data.get("results", []):
            extra = r.get("extra", {})
            meta = extra.get("metadata", {}) or {}
            sev = {"ERROR": "high", "WARNING": "medium", "INFO": "low"}.get(extra.get("severity", ""), "medium")
            impact = str(meta.get("impact", "")).lower()
            if impact == "high" and sev == "high" and str(meta.get("confidence", "")).lower() == "high":
                sev = "critical"
            cat = meta.get("category", "security")
            category = {"security": "security", "correctness": "bug", "best-practice": "quality",
                        "performance": "quality", "maintainability": "quality"}.get(cat, "security")
            rel = project.rel(r.get("path", ""))
            line = r.get("start", {}).get("line", 0)
            refs = meta.get("references", []) or []
            findings.append(Finding(
                title=(extra.get("message", "").split(".")[0] or r.get("check_id", ""))[:140],
                severity=sev, category=category, scanner=self.name, rule_id=r.get("check_id", ""), file=rel, line=line,
                description=extra.get("message", ""),
                recommendation=(f"Suggested fix: {extra['fix']}" if extra.get("fix") else
                                "See the rule references for remediation guidance."),
                snippet=read_line(project, rel, line), cwe=_first_cwe(meta.get("cwe")),
                references=refs if isinstance(refs, list) else [refs],
            ))
        return findings


class GitleaksScanner(Scanner):
    name = "gitleaks"
    binary = "gitleaks"
    description = "Gitleaks: 150+ secret / API-key detectors"
    install_hint = "https://github.com/gitleaks/gitleaks/releases"

    def run(self, project: Project) -> list[Finding]:
        with tempfile.TemporaryDirectory() as tmp:
            report = Path(tmp) / "gitleaks.json"
            proc = run_cmd(["gitleaks", "dir", str(project.root), "--report-format", "json", "--report-path", str(report),
                            "--no-banner", "--redact", "--exit-code", "0", "--log-level", "error"], project.root)
            if not report.exists():
                raise RuntimeError(proc.stderr.strip()[:300] or "no report produced")
            data = json.loads(report.read_text() or "[]")
        findings = []
        for leak in data or []:
            rel = project.rel(leak.get("File", ""))
            if project.is_excluded(rel):
                continue
            findings.append(Finding(
                title=f"Secret detected: {leak.get('Description') or leak.get('RuleID')}", severity="critical"
                if leak.get("RuleID", "").startswith(("aws", "private-key", "github", "gcp", "stripe")) else "high",
                category="secret", scanner=self.name, rule_id=f"gitleaks/{leak.get('RuleID', '')}", file=rel,
                line=leak.get("StartLine", 0),
                description="A secret matching a known credential format was found in the source tree.",
                recommendation="Revoke and rotate this credential, purge it from git history, and load it from a secret manager.",
                snippet=(leak.get("Match") or "")[:200], cwe="CWE-798",
            ))
        return findings


class OsvScanner(Scanner):
    name = "osv-scanner"
    binary = "osv-scanner"
    description = "OSV-Scanner: known CVEs in dependencies (npm, PyPI, Go, Maven, Cargo, NuGet, RubyGems, Packagist...)"
    install_hint = "https://github.com/google/osv-scanner/releases"

    def is_applicable(self, project: Project) -> bool:
        return bool(project.manifests)

    def run(self, project: Project) -> list[Finding]:
        proc = run_cmd(["osv-scanner", "scan", "source", "-r", "--format", "json", str(project.root)], project.root)
        if proc.returncode not in (0, 1) and not proc.stdout.strip():
            if "no package sources found" in proc.stderr.lower():
                raise ScannerSkipped("no supported lockfiles/manifests found")
            raise RuntimeError(proc.stderr.strip()[-300:] or f"exit code {proc.returncode}")
        data = json.loads(proc.stdout or "{}")
        findings = []
        for result in data.get("results", []) or []:
            src = project.rel(result.get("source", {}).get("path", ""))
            for pkg in result.get("packages", []) or []:
                f = self._package_finding(src, pkg)
                if f:
                    findings.append(f)
        return findings

    @staticmethod
    def _package_finding(src: str, pkg: dict) -> Finding | None:
        p = pkg.get("package", {})
        name, version, eco = p.get("name", "?"), p.get("version", "?"), p.get("ecosystem", "")
        vulns = {v["id"]: v for v in pkg.get("vulnerabilities", []) or []}
        groups = pkg.get("groups", []) or [{"ids": [i]} for i in vulns]
        if not groups:
            return None
        entries, fixed_versions, refs, cwes = [], set(), [], []
        worst = "info"
        for group in groups:
            ids = group.get("ids", [])
            vuln = next((vulns[i] for i in ids if i in vulns), {})
            try:
                score = float(group.get("max_severity") or 0) or None
            except ValueError:
                score = None
            sev = severity_from_cvss(score) if score else normalize_severity(
                (vuln.get("database_specific") or {}).get("severity"), "medium")
            if SEVERITY_RANK[sev] > SEVERITY_RANK[worst]:
                worst = sev
            fixed_versions |= {ev["fixed"] for aff in vuln.get("affected", []) or []
                               if (aff.get("package") or {}).get("name") == name
                               for rng in aff.get("ranges", []) or [] for ev in rng.get("events", []) if "fixed" in ev}
            aliases = [a for a in vuln.get("aliases", []) or [] if a.startswith("CVE-")]
            vid = aliases[0] if aliases else (ids[0] if ids else "?")
            summary = vuln.get("summary") or (vuln.get("details") or "").split("\n")[0][:160] or "Known vulnerability"
            entries.append((SEVERITY_RANK[sev], f"- [{sev.upper()}] {vid}{f' (CVSS {score})' if score else ''}: {summary}"))
            refs += [f"https://osv.dev/vulnerability/{i}" for i in ids[:1]]
            cwes.append(_first_cwe((vuln.get("database_specific") or {}).get("cwe_ids")))
        entries.sort(key=lambda e: -e[0])
        target = max(fixed_versions, key=_version_key) if fixed_versions else ""
        n = len(entries)
        return Finding(
            title=f"Vulnerable dependency {name}@{version}: {n} known vulnerabilit{'y' if n == 1 else 'ies'}",
            severity=worst, category="dependency", scanner="osv-scanner", rule_id=f"osv/{eco}/{name}", file=src, line=0,
            description=f"{eco} package {name} {version} is affected by:\n" + "\n".join(e[1] for e in entries),
            recommendation=(f"Upgrade {name} to {target} or later (fixes all {n} listed issues where a fix exists)."
                            if target else f"No fixed version published; consider replacing {name} or mitigating."),
            snippet=f"{name}=={version}", cwe=next((c for c in cwes if c), ""), references=refs[:5],
        )


def _version_key(v: str) -> tuple:
    return tuple(int(x) if x.isdigit() else -1 for x in re.split(r"[.\-+]", v))


class BanditScanner(Scanner):
    name = "bandit"
    binary = "bandit"
    description = "Bandit: Python security linter"
    install_hint = "pip install bandit"

    def is_applicable(self, project: Project) -> bool:
        return project.has("Python")

    def run(self, project: Project) -> list[Finding]:
        excludes = ",".join(f"*/{e}/*" for e in project.excludes if "*" not in e)
        proc = run_cmd(["bandit", "-r", str(project.root), "-f", "json", "-q", "-x", excludes], project.root)
        data = json.loads(proc.stdout or "{}")
        findings = []
        for r in data.get("results", []):
            rel = project.rel(r.get("filename", ""))
            if project.is_excluded(rel) or (r.get("test_id") == "B101" and is_test_file(rel)):
                continue
            sev = normalize_severity(r.get("issue_severity"))
            if sev == "high" and r.get("issue_confidence") == "LOW":
                sev = "medium"
            findings.append(Finding(
                title=r.get("issue_text", "")[:140], severity=sev, category="security", scanner=self.name,
                rule_id=f"bandit/{r.get('test_id')}", file=rel, line=r.get("line_number", 0),
                description=f"{r.get('issue_text', '')} (confidence: {r.get('issue_confidence', '').lower()})",
                recommendation=f"See {r.get('more_info', '')}", snippet=read_line(project, rel, r.get("line_number", 0)),
                cwe=f"CWE-{r['issue_cwe']['id']}" if r.get("issue_cwe", {}).get("id") else "",
                references=[r["more_info"]] if r.get("more_info") else [],
            ))
        return findings


class ShellcheckScanner(Scanner):
    name = "shellcheck"
    binary = "shellcheck"
    description = "ShellCheck: bugs in shell scripts"
    install_hint = "apt install shellcheck"

    def is_applicable(self, project: Project) -> bool:
        return project.has("Shell")

    def run(self, project: Project) -> list[Finding]:
        files = [str(f) for f in project.files_for({"Shell"})]
        proc = run_cmd(["shellcheck", "-f", "json", *files], project.root)
        findings = []
        for r in json.loads(proc.stdout or "[]"):
            rel = project.rel(r.get("file", ""))
            findings.append(Finding(
                title=r.get("message", "")[:140], severity={"error": "high", "warning": "medium"}.get(r.get("level"), "low"),
                category="bug", scanner=self.name, rule_id=f"SC{r.get('code')}", file=rel, line=r.get("line", 0),
                description=r.get("message", ""), recommendation=f"See https://www.shellcheck.net/wiki/SC{r.get('code')}",
                snippet=read_line(project, rel, r.get("line", 0)),
                references=[f"https://www.shellcheck.net/wiki/SC{r.get('code')}"],
            ))
        return findings


class HadolintScanner(Scanner):
    name = "hadolint"
    binary = "hadolint"
    description = "Hadolint: Dockerfile best practices"
    install_hint = "https://github.com/hadolint/hadolint/releases"

    def is_applicable(self, project: Project) -> bool:
        return project.has("Dockerfile")

    def run(self, project: Project) -> list[Finding]:
        findings = []
        for f in project.files_for({"Dockerfile"}):
            proc = run_cmd(["hadolint", "-f", "json", str(f)], project.root)
            for r in json.loads(proc.stdout or "[]"):
                rel = project.rel(f)
                findings.append(Finding(
                    title=r.get("message", "")[:140], severity={"error": "high", "warning": "medium"}.get(r.get("level"), "low"),
                    category="config", scanner=self.name, rule_id=r.get("code", ""), file=rel, line=r.get("line", 0),
                    description=r.get("message", ""), recommendation="Follow the hadolint rule guidance.",
                    snippet=read_line(project, rel, r.get("line", 0)),
                ))
        return findings
