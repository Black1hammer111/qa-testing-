# qa-sentinel: ignore-file  (rule patterns and texts describe the vulnerabilities they detect)
"""Built-in, dependency-free rule engine.

Works on any text-based language. Each rule is a set of regular expressions scoped
to a group of languages. Projects can add their own rules via the `rules` key of
`.qa-sentinel.json`, which makes the engine extensible to any language.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from qa_sentinel.models import Finding
from qa_sentinel.project import Project, is_test_file, language_of
from qa_sentinel.scanners.base import Scanner

SUPPRESS_MARKER = re.compile(r"qa-sentinel:\s*ignore|nosec|noqa:\s*qa", re.I)
# A file whose first lines carry this marker is skipped entirely (e.g. rule definitions).
SUPPRESS_FILE = re.compile(r"qa-sentinel:\s*ignore-file", re.I)
SUPPRESS_FILE_LINES = 10
COMMENT_LINE = re.compile(r"^\s*(//|/\*|\*|<!--|--\s|#(?!include|define|if|pragma|!)|'''|\"\"\")")
COMMENT_AWARE_CATEGORIES = {"secret", "quality"}

PY = {"Python"}
JS = {"JavaScript", "TypeScript", "Vue", "Svelte", "HTML"}
JVM = {"Java", "Kotlin", "Scala"}
C_LIKE = {"C", "C++", "Objective-C"}
CODE = (
    PY | JS | JVM | C_LIKE
    | {"Go", "Ruby", "PHP", "C#", "VB.NET", "Rust", "Swift", "Dart", "Lua", "Perl", "R", "Elixir",
       "Erlang", "Haskell", "Clojure", "Shell", "PowerShell", "Groovy"}
)
CONFIGS = {"YAML", "JSON", "TOML", "INI", "Env", "Properties", "Config", "XML", "Terraform", "Dockerfile", "Makefile"}
ANY = None


@dataclass
class Rule:
    id: str
    title: str
    severity: str
    category: str
    patterns: list[str]
    languages: set[str] | None = ANY
    description: str = ""
    recommendation: str = ""
    cwe: str = ""
    skip_tests: bool = False
    flags: int = 0
    compiled: list[re.Pattern] = field(default_factory=list, repr=False)

    def __post_init__(self) -> None:
        self.compiled = [re.compile(p, self.flags) for p in self.patterns]


I = re.IGNORECASE

RULES: list[Rule] = [
    # ---------------------------------------------------------------- injection
    Rule("QAS-INJ-001", "Dynamic code execution (eval)", "high", "security",
         [r"(?<![\w.])eval\s*\(", r"\bnew\s+Function\s*\("], PY | JS | {"PHP", "Ruby", "Perl", "Lua"},
         "Evaluating dynamically built strings lets an attacker who controls any part of the input run arbitrary code.",
         "Remove eval/new Function. Parse data with a safe parser (e.g. json.loads / JSON.parse / ast.literal_eval) or use a dispatch table.",
         "CWE-95"),
    Rule("QAS-INJ-002", "Dynamic code execution (exec)", "high", "security",
         [r"(?<![\w.])exec\s*\((?!\s*\))"], PY,
         "exec() runs arbitrary Python code; any user-influenced input becomes remote code execution.",
         "Avoid exec(). Use explicit functions, importlib for plugins, or a sandboxed interpreter.", "CWE-95"),
    Rule("QAS-INJ-003", "OS command injection risk", "high", "security",
         [r"\bos\.(system|popen)\s*\(", r"\bsubprocess\.\w+\([^)]*shell\s*=\s*True", r"\bcommands\.getoutput\("],
         PY,
         "Commands executed through a shell are vulnerable to injection when they contain user-controlled data.",
         "Use subprocess.run([...], shell=False) with an argument list and validate inputs (shlex.quote if a shell is unavoidable).",
         "CWE-78"),
    Rule("QAS-INJ-004", "OS command injection risk", "high", "security",
         [r"\b(?:child_process\.)?exec(?:Sync)?\s*\([^)]*(\+|\$\{)", r"\bspawn\([^)]*shell\s*:\s*true"], JS,
         "child_process.exec runs the command through a shell; concatenated input allows command injection.",
         "Use execFile/spawn with an argument array and no shell, and validate inputs against an allow-list.", "CWE-78"),
    Rule("QAS-INJ-005", "OS command injection risk", "high", "security",
         [r"\b(system|shell_exec|passthru|popen|proc_open)\s*\(\s*\$", r"`[^`]*\$\w+[^`]*`"], {"PHP"},
         "Passing variables to shell functions enables command injection.",
         "Use escapeshellarg() on every argument or avoid the shell entirely.", "CWE-78"),
    Rule("QAS-INJ-006", "OS command injection risk", "high", "security",
         [r"Runtime\.getRuntime\(\)\.exec\(", r"new\s+ProcessBuilder\([^)]*\+"], JVM,
         "Runtime.exec with concatenated strings can lead to command injection.",
         "Use ProcessBuilder with a fixed command and separate, validated arguments.", "CWE-78"),
    Rule("QAS-INJ-007", "Shell invoked from code", "medium", "security",
         [r"exec\.Command\(\s*\"(sh|bash|cmd|powershell)\"", r"Process\.Start\(\s*\"(cmd|powershell)", r"%x\(|`[^`]*#\{"],
         {"Go", "C#", "Ruby"},
         "Spawning a shell interpreter with dynamic arguments is prone to command injection.",
         "Execute the target binary directly with an argument list; never interpolate user input into a shell string.",
         "CWE-78"),
    Rule("QAS-INJ-010", "SQL query built from strings (SQL injection)", "high", "security",
         [r"(?i)\"[^\"]*\b(select\s.+\sfrom|insert\s+into|update\s+\w+\s+set|delete\s+from)\b[^\"]*\"\s*(\+|%\s*[\w(]|\.format\()",
          r"(?i)'[^']*\b(select\s.+\sfrom|insert\s+into|update\s+\w+\s+set|delete\s+from)\b[^']*'\s*(\+|%\s*[\w(]|\.format\()",
          r"(?i)\b(select\s.+\sfrom|insert\s+into|update\s+\w+\s+set|delete\s+from)\b.*[\"']\s*\+\s*\w+(\s*\+\s*[\"']|\s*[),;])",
          r"(?i)\bf[\"'][^\"']*\b(select\s.+\sfrom|insert\s+into|update\s+\w+\s+set|delete\s+from)\b[^\"']*\{",
          r"(?i)`[^`]*\b(select\s.+\sfrom|insert\s+into|update\s+\w+\s+set|delete\s+from)\b[^`]*\$\{",
          r"(?i)\"[^\"]*\b(select\s.+\sfrom|insert\s+into|update\s+\w+\s+set|delete\s+from)\b[^\"]*\$\w+"],
         CODE,
         "The SQL statement is assembled with string concatenation / formatting. Attacker-controlled values can change the query logic.",
         "Use parameterized queries / prepared statements (e.g. cursor.execute(sql, params), PreparedStatement, ORM query builders).",
         "CWE-89"),
    Rule("QAS-INJ-011", "LDAP / XPath query built from strings", "medium", "security",
         [r"(?i)(search_s|search)\([^)]*\(\w+=\"\s*\+", r"(?i)xpath\([^)]*\+"], CODE,
         "Queries built with concatenation can be manipulated by injected metacharacters.",
         "Escape special characters or use parameterized APIs.", "CWE-90"),
    # -------------------------------------------------------------- web / XSS
    Rule("QAS-XSS-001", "Possible Cross-Site Scripting (unsafe HTML sink)", "medium", "security",
         [r"\.innerHTML\s*=", r"\.outerHTML\s*=", r"dangerouslySetInnerHTML", r"document\.write\s*\(",
          r"\bv-html\s*=", r"\|\s*safe\b", r"\bmark_safe\s*\(", r"\{\{\{[^}]+\}\}\}", r"\bhtml_safe\b", r"<%==",
          r"Markup\s*\(", r"render_template_string\s*\("],
         JS | PY | {"Ruby", "PHP", "HTML"},
         "Inserting untrusted data into HTML without encoding allows script injection in users' browsers.",
         "Use textContent / framework auto-escaping; if HTML is required sanitize it with a vetted library (e.g. DOMPurify, bleach).",
         "CWE-79"),
    Rule("QAS-XSS-002", "Reflected output of request data", "medium", "security",
         [r"echo\s+\$_(GET|POST|REQUEST|COOKIE)", r"res\.send\([^)]*req\.(query|params|body)",
          r"return\s+[^\n]*request\.(args|form|values)\.get\("],
         JS | PY | {"PHP"},
         "Request parameters are written to the response without encoding.",
         "Encode output for its context (htmlspecialchars, template escaping) and validate inputs.", "CWE-79"),
    Rule("QAS-WEB-001", "Path traversal: file access built from request data", "high", "security",
         [r"(open|readFile|readFileSync|createReadStream|sendFile|send_file|send_from_directory|File|fopen|file_get_contents|include|require)\s*\([^)]*\b(request|req|params|\$_GET|\$_POST|\$_REQUEST)\b"],
         CODE,
         "File paths derived from user input can be manipulated with ../ sequences to read or overwrite arbitrary files.",
         "Resolve the path, verify it stays inside an allowed base directory, and prefer an allow-list of file names.",
         "CWE-22"),
    Rule("QAS-WEB-002", "Server-Side Request Forgery risk", "medium", "security",
         [r"(requests\.(get|post|put|delete)|urlopen|fetch|axios\.(get|post)|http\.Get|HttpClient\.\w+)\s*\([^)]*\b(request|req)\.(args|query|params|body|form|GET|POST)"],
         CODE,
         "Outbound requests to user-supplied URLs can be abused to reach internal services (cloud metadata, admin panels).",
         "Validate URLs against an allow-list of hosts/schemes and block private IP ranges.", "CWE-918"),
    Rule("QAS-WEB-003", "Open redirect", "medium", "security",
         [r"redirect\s*\([^)]*\b(request|req)\.(args|query|params|GET|form)", r"header\(\s*[\"']Location:\s*[\"']\s*\.\s*\$_(GET|REQUEST)"],
         CODE,
         "Redirecting to a user-controlled URL enables phishing via trusted domains.",
         "Only redirect to relative paths or an allow-list of destinations.", "CWE-601"),
    Rule("QAS-WEB-004", "Permissive CORS policy", "low", "config",
         [r"Access-Control-Allow-Origin[\"']?\s*[:,]\s*[\"']\*", r"origins?\s*[:=]\s*[\"']\*[\"']", r"AllowAnyOrigin\(\)"],
         ANY,
         "A wildcard CORS policy lets any website read responses from this API.",
         "Restrict allowed origins to the domains that need access.", "CWE-942"),
    Rule("QAS-WEB-005", "CSRF protection disabled", "medium", "security",
         [r"csrf\(\)\.disable\(\)", r"@csrf_exempt", r"csrf_protect\s*=\s*False", r"WTF_CSRF_ENABLED\s*=\s*False",
          r"skip_before_action\s+:verify_authenticity_token"],
         ANY,
         "Disabling CSRF protection lets other sites perform state-changing requests on behalf of logged-in users.",
         "Keep CSRF protection enabled; exempt only stateless token-authenticated APIs.", "CWE-352"),
    # -------------------------------------------------------- crypto / auth
    Rule("QAS-CRY-001", "Weak hashing algorithm (MD5/SHA-1)", "medium", "security",
         [r"\bhashlib\.(md5|sha1)\b(?!.*usedforsecurity\s*=\s*False)", r"MessageDigest\.getInstance\(\s*\"(MD5|SHA-?1)\"", r"createHash\(\s*[\"'](md5|sha1)[\"']",
          r"(?<![\w.])(md5|sha1)\s*\(", r"\bmd5\.New\(|\bsha1\.New\(", r"\b(MD5|SHA1)\.Create\(", r"Digest::(MD5|SHA1)"],
         CODE,
         "MD5 and SHA-1 are broken for collision resistance and too fast for password storage.",
         "Use SHA-256+ for integrity, and bcrypt/scrypt/Argon2/PBKDF2 for passwords.", "CWE-327"),
    Rule("QAS-CRY-002", "Weak or broken cipher", "high", "security",
         [r"\b(DES|RC4|RC2|Blowfish)\b(?!\w)", r"AES/ECB", r"MODE_ECB", r"\bdes-ede\b", r"Cipher\.getInstance\(\s*\"AES\"\s*\)"],
         CODE,
         "DES/RC4/ECB mode do not provide adequate confidentiality.",
         "Use AES-GCM or ChaCha20-Poly1305 from a well-maintained library.", "CWE-327"),
    Rule("QAS-CRY-003", "Insecure randomness", "low", "security",
         [r"\bMath\.random\(\)", r"\brandom\.(random|randint|choice|randrange)\(", r"(?<![\w.])rand\(\)", r"new\s+Random\(",
          r"\bmath/rand\b", r"\bmt_rand\("],
         CODE,
         "Non-cryptographic random generators are predictable; this is a vulnerability if the value is used for tokens, passwords or IDs.",
         "Use a CSPRNG: secrets / os.urandom (Python), crypto.randomUUID / crypto.getRandomValues (JS), SecureRandom (Java), crypto/rand (Go).",
         "CWE-330", skip_tests=True),
    Rule("QAS-CRY-004", "TLS certificate verification disabled", "high", "security",
         [r"verify\s*=\s*False", r"rejectUnauthorized\s*:\s*false", r"InsecureSkipVerify\s*:\s*true",
          r"NODE_TLS_REJECT_UNAUTHORIZED[\"']?\s*[]=:)]?\s*[\"']?0", r"CURLOPT_SSL_VERIFYPEER\s*,\s*(false|0)",
          r"ssl\._create_unverified_context", r"CERT_NONE", r"ServerCertificateValidationCallback\s*=.*true",
          r"TrustAllCerts|X509TrustManager\s*\{"],
         CODE,
         "Disabling certificate validation makes TLS connections vulnerable to man-in-the-middle attacks.",
         "Keep certificate verification on; add internal CAs to the trust store instead of disabling checks.", "CWE-295"),
    Rule("QAS-AUTH-001", "JWT signature verification disabled", "high", "security",
         [r"jwt\.decode\([^)]*verify\s*=\s*False", r"verify_signature[\"']?\s*:\s*False", r"algorithms\s*=\s*\[\s*[\"']none",
          r"algorithm[\"']?\s*:\s*[\"']none", r"\.parseUnsecuredClaims|setSigningKey\(\s*\"\""],
         CODE,
         "Tokens are accepted without verifying their signature, so anyone can forge them.",
         "Always verify JWTs with an explicit algorithm allow-list and the correct key.", "CWE-347"),
    # ----------------------------------------------------- deserialization
    Rule("QAS-DES-001", "Insecure deserialization", "high", "security",
         [r"\bpickle\.loads?\(", r"\bcPickle\.loads?\(", r"\byaml\.load\((?![^)]*SafeLoader)(?![^)]*safe_load)", r"\byaml\.unsafe_load\(",
          r"\bmarshal\.loads?\(", r"\bshelve\.open\(", r"(?<![\w.])unserialize\s*\(", r"new\s+ObjectInputStream\(",
          r"\bMarshal\.load\b", r"\bBinaryFormatter\b", r"\bnode-serialize\b|serialize\.unserialize\("],
         CODE,
         "Deserializing untrusted data with these APIs can execute arbitrary code.",
         "Use data-only formats (JSON) or safe loaders (yaml.safe_load); never deserialize data from untrusted sources.",
         "CWE-502"),
    Rule("QAS-XXE-001", "XML parser may allow external entities (XXE)", "medium", "security",
         [r"\bxml\.etree\.ElementTree\b|\bxml\.dom\.minidom\b|\bxml\.sax\b", r"DocumentBuilderFactory\.newInstance\(\)",
          r"XMLInputFactory\.newInstance\(\)", r"libxml_disable_entity_loader\(\s*false", r"resolve_entities\s*=\s*True"],
         CODE,
         "Default XML parsers may resolve external entities, enabling file disclosure or SSRF.",
         "Use defusedxml (Python) or disable DTDs/external entities on the parser factory.", "CWE-611"),
    # --------------------------------------------------------- memory safety
    Rule("QAS-MEM-001", "Unsafe C string/memory function", "high", "security",
         [r"(?<![\w.])(gets|strcpy|strcat|sprintf|vsprintf|scanf|sscanf)\s*\("], C_LIKE,
         "These functions perform no bounds checking and are a classic source of buffer overflows.",
         "Use bounded alternatives: fgets, strncpy/strlcpy, snprintf, and validate lengths.", "CWE-120"),
    Rule("QAS-MEM-002", "Unsafe Rust block", "low", "security", [r"\bunsafe\s*\{"], {"Rust"},
         "Code inside unsafe blocks bypasses Rust's memory safety guarantees.",
         "Minimise unsafe code, document invariants and cover it with tests / Miri.", "CWE-119"),
    # ---------------------------------------------------- hardcoded secrets
    Rule("QAS-SEC-001", "Hardcoded credential", "high", "secret",
         [r"(?i)\b[\w-]*(password|passwd|pwd|secret|api[_-]?key|apikey|access[_-]?key|auth[_-]?token|private[_-]?key|client[_-]?secret)(?:[_-]?(?:key|value|token|id))?\b[\"'\]]*\s*(:=|=>|=|:)\s*[\"'](?!\s*[\"'])(?![^\"']*(\$\{|\{\{|<|your|example|changeme|xxx|\*\*\*|placeholder|dummy|test|env|getenv))[^\"'\s]{4,}[\"']"],
         ANY,
         "A credential appears to be committed in source code. Anyone with repository access (or a leaked copy) can use it.",
         "Remove it from the code, rotate the credential, and load it from environment variables or a secrets manager.",
         "CWE-798"),
    Rule("QAS-SEC-002", "AWS access key", "critical", "secret", [r"\b(AKIA|ASIA)[0-9A-Z]{16}\b"], ANY,
         "An AWS access key ID is committed.", "Deactivate and rotate the key in AWS IAM immediately; use IAM roles or a secrets manager.",
         "CWE-798"),
    Rule("QAS-SEC-003", "Private key committed", "critical", "secret",
         [r"-----BEGIN (RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY( BLOCK)?-----"], ANY,
         "A private key is stored in the repository.", "Revoke the key, remove it from git history, and store keys in a vault.",
         "CWE-321"),
    Rule("QAS-SEC-004", "API token committed", "critical", "secret",
         [r"\bgh[pousr]_[A-Za-z0-9]{36,}\b", r"\bgithub_pat_[A-Za-z0-9_]{60,}\b", r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b",
          r"\bAIza[0-9A-Za-z\-_]{35}\b", r"\b[sr]k_live_[0-9a-zA-Z]{20,}\b", r"\bSG\.[\w-]{22}\.[\w-]{43}\b",
          r"\bglpat-[0-9A-Za-z\-_]{20}\b", r"\bnpm_[A-Za-z0-9]{36}\b", r"\bsk-[A-Za-z0-9]{32,}\b"],
         ANY,
         "A live API token for a third-party service is committed.", "Revoke the token with the provider and load it from a secret store.",
         "CWE-798"),
    Rule("QAS-SEC-005", "Credentials embedded in connection string", "high", "secret",
         [r"\b(postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis|amqp|mssql|ftp|smtp)://[^\s:/@\"']+:[^\s@/\"'$<{]{3,}@[^\s\"']+"], ANY,
         "A connection URL contains a username and password.", "Move credentials into environment variables / secret manager and rotate them.",
         "CWE-798"),
    # ------------------------------------------------------- configuration
    Rule("QAS-CFG-001", "Debug mode enabled", "medium", "config",
         [r"\bapp\.run\([^)]*debug\s*=\s*True", r"^\s*DEBUG\s*=\s*True\b", r"\bdisplay_errors\s*=\s*(On|1)\b",
          r"app\.UseDeveloperExceptionPage\(\)"],
         CODE | CONFIGS,
         "Debug mode exposes stack traces, configuration and sometimes an interactive console to attackers.",
         "Disable debug in production; drive it from an environment variable that defaults to off.", "CWE-489"),
    Rule("QAS-CFG-002", "Service bound to all network interfaces", "low", "config",
         [r"[\"']0\.0\.0\.0[\"']", r"host\s*=\s*[\"']0\.0\.0\.0"], CODE,
         "Binding to 0.0.0.0 exposes the service on every interface.",
         "Bind to 127.0.0.1 unless external access is intended and protected.", "CWE-1327", skip_tests=True),
    Rule("QAS-CFG-003", "Remote script piped to shell", "high", "config",
         [r"(curl|wget)\s[^|\n]*\|\s*(sudo\s+)?(ba|z)?sh\b"], ANY,
         "Downloading and executing a script without verification allows supply-chain compromise.",
         "Download, verify a checksum/signature, then execute; or use a package manager.", "CWE-494"),
    Rule("QAS-CFG-004", "World-writable permissions", "medium", "config",
         [r"chmod\s+(-R\s+)?0?777\b", r"os\.chmod\([^)]*0o?777", r"\bumask\s*\(?\s*0?000\b"], ANY,
         "Files made world-writable can be modified by any local user or process.", "Use least-privilege permissions (e.g. 750/640).",
         "CWE-732"),
    Rule("QAS-CFG-010", "Container image without pinned tag", "medium", "config",
         [r"(?i)^\s*FROM\s+(?!scratch\b)[^\s:@$]+(:latest)?(\s+AS\s+\S+)?\s*$"], {"Dockerfile"},
         "Unpinned / 'latest' base images make builds non-reproducible and can silently pull vulnerable versions.",
         "Pin the base image to a specific version tag or digest.", "CWE-1104"),
    Rule("QAS-CFG-011", "Secret passed via Dockerfile ENV/ARG", "high", "secret",
         [r"(?i)^\s*(ENV|ARG)\s+\w*(PASSWORD|PASSWD|SECRET|TOKEN|API_?KEY|PRIVATE_?KEY)\w*[\s=]+\S+"], {"Dockerfile"},
         "Values in ENV/ARG are baked into image layers and visible to anyone who can pull the image.",
         "Use BuildKit secrets (--mount=type=secret) or inject at runtime.", "CWE-538"),
    Rule("QAS-CFG-012", "ADD with remote URL", "medium", "config", [r"(?i)^\s*ADD\s+https?://"], {"Dockerfile"},
         "ADD from a URL downloads content without integrity verification.", "Use curl with checksum verification, or COPY local files.",
         "CWE-494"),
    Rule("QAS-CFG-020", "Privileged container / host access", "high", "config",
         [r"privileged:\s*true", r"allowPrivilegeEscalation:\s*true", r"hostNetwork:\s*true", r"hostPID:\s*true",
          r"--privileged\b", r"runAsUser:\s*0\b"],
         ANY,
         "Privileged containers can escape to the host.", "Drop privileges: run as non-root, disallow privilege escalation, avoid host namespaces.",
         "CWE-250"),
    Rule("QAS-CFG-021", "Publicly exposed cloud resource", "high", "config",
         [r"acl\s*=\s*\"public-read(-write)?\"", r"cidr_blocks\s*=\s*\[\s*\"0\.0\.0\.0/0\"", r"publicly_accessible\s*=\s*true",
          r"\"Principal\"\s*:\s*\"\*\""],
         {"Terraform", "JSON", "YAML"},
         "The resource is reachable from the internet / readable by anyone.", "Restrict access to required principals and CIDR ranges.",
         "CWE-284"),
    # ------------------------------------------------------------ bugs
    Rule("QAS-BUG-001", "Bare except swallows all errors", "low", "bug", [r"^\s*except\s*:\s*(#.*)?$"], PY,
         "A bare except also catches KeyboardInterrupt/SystemExit and hides real failures.",
         "Catch specific exceptions (e.g. except ValueError:) and log or re-raise.", "CWE-396"),
    Rule("QAS-BUG-002", "Mutable default argument", "medium", "bug",
         [r"def\s+\w+\s*\([^)]*=\s*(\[\]|\{\}|set\(\)|dict\(\)|list\(\))\s*[,)]"], PY,
         "Default values are evaluated once, so the same list/dict is shared across calls and state leaks between them.",
         "Use None as the default and create the object inside the function.", "CWE-1188"),
    Rule("QAS-BUG-003", "Identity comparison with literal", "medium", "bug",
         [r"\bis\s+(not\s+)?(-?\d+|[\"'][^\"']*[\"'])(?!\w)"], PY,
         "'is' compares object identity, not value; results with literals are implementation dependent.",
         "Use == / != for value comparison.", "CWE-597"),
    Rule("QAS-BUG-004", "Empty catch block hides errors", "medium", "bug",
         [r"catch\s*(\([^)]*\))?\s*\{\s*\}", r"except\s+[\w.,() ]+:\s*pass\s*$", r"rescue\s*(=>\s*\w+)?\s*;?\s*end"], CODE,
         "Exceptions are silently ignored, so failures go unnoticed and are hard to diagnose.",
         "Handle the error, log it, or let it propagate.", "CWE-390"),
    Rule("QAS-BUG-005", "String compared with == in Java", "medium", "bug",
         [r"\"[^\"]*\"\s*[!=]=\s*\w", r"\w\s*[!=]=\s*\"[^\"]*\""], {"Java"},
         "In Java == compares references, so equal strings may compare as different.", "Use .equals() / Objects.equals().",
         "CWE-597"),
    Rule("QAS-BUG-006", "Loose equality comparison", "low", "bug", [r"[^=!<>]==[^=]", r"!=[^=]"], {"JavaScript", "TypeScript"},
         "== / != perform type coercion and produce surprising results (e.g. '' == 0).", "Use === / !==.", "CWE-1025"),
    Rule("QAS-BUG-007", "Comparison to None using ==", "low", "bug", [r"[=!]=\s*None\b"], PY,
         "Comparing with == None can be overridden by __eq__ and is not idiomatic.", "Use 'is None' / 'is not None'.", "CWE-595"),
    Rule("QAS-BUG-008", "Error return value ignored", "low", "bug", [r"^\s*_\s*(,\s*_\s*)?=\s*[\w.]+\("], {"Go"},
         "The returned error is discarded, so failures go unnoticed.", "Check the error and handle or return it.", "CWE-252"),
    Rule("QAS-BUG-009", "Assert used for runtime validation", "low", "bug", [r"^\s*assert\s"], PY,
         "assert statements are removed when Python runs with -O, disabling these checks in production.",
         "Raise explicit exceptions for validation.", "CWE-617", skip_tests=True),
    Rule("QAS-BUG-010", "Floating point equality comparison", "low", "bug", [r"[=!]=\s*\d+\.\d+\b"], CODE,
         "Floating point values are rarely exactly equal due to rounding.", "Compare with a tolerance (math.isclose, Math.abs(a-b) < eps).",
         "CWE-1077", skip_tests=True),
    Rule("QAS-BUG-011", "Unchecked use of Python 'input' for code", "high", "security",
         [r"(eval|exec)\s*\(\s*input\s*\("], PY, "User input is executed as code.", "Parse input explicitly; never evaluate it.",
         "CWE-95"),
    # ---------------------------------------------------------- quality
    Rule("QAS-QLT-001", "Unresolved TODO / FIXME", "info", "quality",
         [r"(#|//|/\*|<!--|--|;)\s*(TODO|FIXME|HACK|XXX|BUG)\b"], ANY,
         "Marker for unfinished or known-broken code.", "Resolve the note or track it in the issue tracker.", ""),
    Rule("QAS-QLT-002", "Debug statement left in code", "info", "quality",
         [r"\bconsole\.log\(", r"(?<![\w.])breakpoint\(\)", r"\bpdb\.set_trace\(\)", r"\bdebugger;", r"\bvar_dump\(",
          r"\bprintStackTrace\(\)"],
         CODE,
         "Debug output can leak internal data and clutters logs.", "Remove it or replace it with structured logging.", "CWE-489",
         skip_tests=True),
]


def rule_from_config(raw: dict) -> Rule:
    langs = raw.get("languages")
    return Rule(
        id=raw["id"], title=raw.get("title", raw["id"]), severity=raw.get("severity", "medium"),
        category=raw.get("category", "security"), patterns=list(raw["patterns"]) if "patterns" in raw else [raw["pattern"]],
        languages=set(langs) if langs else ANY, description=raw.get("description", ""),
        recommendation=raw.get("recommendation", ""), cwe=raw.get("cwe", ""), skip_tests=raw.get("skip_tests", False),
        flags=re.IGNORECASE if raw.get("ignore_case") else 0,
    )


class BuiltinRulesScanner(Scanner):
    name = "builtin-rules"
    description = f"{len(RULES)} built-in multi-language rules for injection, XSS, crypto, secrets, config and bug patterns"

    def rules(self, project: Project) -> list[Rule]:
        disabled = set(project.config.get("disable_rules", []))
        rules = [r for r in RULES if r.id not in disabled]
        rules += [rule_from_config(r) for r in project.config.get("rules", [])]
        return rules

    def run(self, project: Project) -> list[Finding]:
        rules = self.rules(project)
        findings: list[Finding] = []
        for path in project.files:
            lang = language_of(path)
            applicable = [r for r in rules if r.languages is None or lang in r.languages]
            if not applicable:
                continue
            rel = project.rel(path)
            test_file = is_test_file(rel)
            try:
                with open(path, encoding="utf-8") as fh:
                    lines = fh.readlines()
            except (UnicodeDecodeError, OSError):
                continue
            if any(SUPPRESS_FILE.search(ln) for ln in lines[:SUPPRESS_FILE_LINES]):
                continue
            for lineno, line in enumerate(lines, 1):
                if len(line) > 2000 or SUPPRESS_MARKER.search(line):
                    continue
                is_comment = bool(COMMENT_LINE.match(line))
                for rule in applicable:
                    if rule.skip_tests and test_file:
                        continue
                    if is_comment and rule.category not in COMMENT_AWARE_CATEGORIES:
                        continue
                    if any(rx.search(line) for rx in rule.compiled):
                        findings.append(Finding(
                            title=rule.title, severity=rule.severity, category=rule.category, scanner=self.name,
                            rule_id=rule.id, file=rel, line=lineno, description=rule.description,
                            recommendation=rule.recommendation, snippet=line.rstrip("\n")[:300], cwe=rule.cwe,
                        ))
            if lang == "Dockerfile":
                findings.extend(self._dockerfile_checks(rel, lines))
        return findings

    def _dockerfile_checks(self, rel: str, lines: list[str]) -> list[Finding]:
        has_user = any(re.match(r"(?i)^\s*USER\s+(?!root\b|0\b)\S+", ln) for ln in lines)
        if has_user or not any(re.match(r"(?i)^\s*FROM\s", ln) for ln in lines):
            return []
        return [Finding(
            title="Container runs as root", severity="medium", category="config", scanner=self.name,
            rule_id="QAS-CFG-013", file=rel, line=1,
            description="No non-root USER instruction found; a compromise of the app gives root inside the container.",
            recommendation="Create an unprivileged user and add 'USER <name>' before the entrypoint.", cwe="CWE-250",
        )]
