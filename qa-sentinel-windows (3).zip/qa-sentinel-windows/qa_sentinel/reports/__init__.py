from __future__ import annotations

import json
from pathlib import Path

from qa_sentinel.reports.html import render_html
from qa_sentinel.reports.markdown import render_markdown
from qa_sentinel.reports.sarif import render_sarif
from qa_sentinel.runner import Report

FORMATS = {
    "html": ("report.html", render_html),
    "json": ("report.json", lambda r: json.dumps(r.to_dict(), indent=2)),
    "sarif": ("report.sarif", lambda r: json.dumps(render_sarif(r), indent=2)),
    "md": ("report.md", render_markdown),
}


def write_reports(report: Report, out_dir: Path, formats: list[str]) -> list[Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    written = []
    for fmt in formats:
        filename, render = FORMATS[fmt]
        path = out_dir / filename
        path.write_text(render(report), encoding="utf-8")
        written.append(path)
    return written
