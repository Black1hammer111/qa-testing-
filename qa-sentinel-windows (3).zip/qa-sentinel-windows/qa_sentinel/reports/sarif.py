from __future__ import annotations

from qa_sentinel import __version__

LEVEL = {"critical": "error", "high": "error", "medium": "warning", "low": "note", "info": "note"}
SECURITY_SEVERITY = {"critical": "9.5", "high": "8.0", "medium": "5.5", "low": "2.0", "info": "0.0"}


def render_sarif(report) -> dict:
    rules: dict[str, dict] = {}
    results = []
    for f in report.findings:
        if f.rule_id not in rules:
            tags = [f.category] + ([f.cwe] if f.cwe else [])
            rules[f.rule_id] = {
                "id": f.rule_id, "name": f.rule_id.replace("/", "_"),
                "shortDescription": {"text": f.title[:200]},
                "fullDescription": {"text": (f.description or f.title)[:1000]},
                "help": {"text": f.recommendation or f.description, "markdown": f.recommendation or f.description},
                "properties": {"tags": tags, "security-severity": SECURITY_SEVERITY[f.severity]},
            }
        res = {
            "ruleId": f.rule_id, "level": LEVEL[f.severity],
            "message": {"text": f"{f.title}. {f.recommendation}".strip()},
            "partialFingerprints": {"qaSentinel/v1": f.fingerprint},
            "properties": {"severity": f.severity, "category": f.category, "scanner": f.scanner},
        }
        if f.file:
            region = {"startLine": max(1, f.line)}
            res["locations"] = [{"physicalLocation": {"artifactLocation": {"uri": f.file}, "region": region}}]
        results.append(res)
    return {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": [{
            "tool": {"driver": {"name": "qa-sentinel", "version": __version__,
                                "informationUri": "https://github.com/", "rules": list(rules.values())}},
            "results": results,
        }],
    }
