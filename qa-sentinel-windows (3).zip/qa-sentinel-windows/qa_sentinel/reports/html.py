from __future__ import annotations

import json
from importlib import resources  # requires Python >= 3.9; nosemgrep

from qa_sentinel.i18n import translations_for
from qa_sentinel.models import CATEGORIES


def render_html(report) -> str:
    template = resources.files("qa_sentinel").joinpath("templates/report.html").read_text(encoding="utf-8")
    data = report.to_dict()
    data["categories"] = CATEGORIES
    data["i18n"] = {"ar": translations_for(data["findings"])}
    data["contexts"] = code_contexts(report)
    payload = json.dumps(data, ensure_ascii=False).replace("<", "\\u003c")
    return template.replace("/*__REPORT_DATA__*/null", payload).replace("__TITLE__", f"QA report: {report.project.root.name}")


def code_contexts(report, radius: int = 6, limit: int = 500) -> dict:
    """Source lines around each finding, used by the report's AI fix prompt."""
    root = report.project.root.resolve()
    cache: dict[str, list[str] | None] = {}
    out = {}
    for f in report.findings[:limit]:
        if not f.file or not f.line:
            continue
        if f.file not in cache:
            try:
                path = (root / f.file).resolve()
                path.relative_to(root)
                cache[f.file] = path.read_text(encoding="utf-8", errors="replace").splitlines()
            except (OSError, ValueError):
                cache[f.file] = None
        lines = cache[f.file]
        if not lines or f.line > len(lines):
            continue
        start = max(1, f.line - radius)
        out[f.fingerprint] = {"start": start, "lines": [ln[:300] for ln in lines[start - 1:f.line + radius]]}
    return out
