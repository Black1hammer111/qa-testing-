from __future__ import annotations

from qa_sentinel.models import CATEGORIES, SEVERITIES

ICON = {"critical": "🟥", "high": "🟧", "medium": "🟨", "low": "🟦", "info": "⬜"}


def _cell(text: str) -> str:
    return text.replace("|", "\\|").replace("\n", " ")


def render_markdown(report, limit: int = 300) -> str:
    d = report.to_dict()
    s = d["summary"]
    out = [
        f"# QA Sentinel report: `{d['project']['name']}`",
        "",
        f"**Grade {s['grade']}** (risk score {s['risk_score']}/100) · {s['total']} findings · "
        f"{d['project']['files_scanned']} files · {d['duration_seconds']}s",
        "",
        "| Severity | Count |", "|---|---|",
        *[f"| {ICON[sev]} {sev} | {s['by_severity'][sev]} |" for sev in SEVERITIES],
        "",
        "**Languages:** " + (", ".join(f"{k} ({v})" for k, v in d["project"]["languages"].items()) or "n/a"),
        "",
        "## Scanners", "", "| Scanner | Status | Findings | Note |", "|---|---|---|---|",
        *[f"| {x['name']} | {x['status']} | {x['findings']} | {_cell(x['message'])} |" for x in d["scanners"]],
        "",
    ]
    for sev in SEVERITIES:
        items = [f for f in report.findings if f.severity == sev]
        if not items:
            continue
        out += [f"## {ICON[sev]} {sev.capitalize()} ({len(items)})", "",
                "| Category | Issue | Location | Fix |", "|---|---|---|---|"]
        for f in items[:limit]:
            loc = f"`{f.location}`" if f.location else ""
            out.append(f"| {CATEGORIES[f.category]} | {_cell(f.title)} | {loc} | {_cell(f.recommendation)[:300]} |")
        if len(items) > limit:
            out.append(f"| | … {len(items) - limit} more | | |")
        out.append("")
    return "\n".join(out)
