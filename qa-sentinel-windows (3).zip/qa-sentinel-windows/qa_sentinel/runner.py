from __future__ import annotations

import math
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable

from qa_sentinel import __version__
from qa_sentinel.models import SEVERITIES, SEVERITY_RANK, SEVERITY_WEIGHT, Finding, ScannerResult, normalize_severity
from qa_sentinel.project import Project
from qa_sentinel.scanners import Scanner, ScannerSkipped, all_scanners


@dataclass
class Report:
    project: Project
    findings: list[Finding]
    scanners: list[ScannerResult]
    started_at: str
    duration: float
    suppressed: int = 0
    meta: dict = field(default_factory=dict)

    def counts(self) -> dict[str, int]:
        c = Counter(f.severity for f in self.findings)
        return {s: c.get(s, 0) for s in SEVERITIES}

    def by_category(self) -> dict[str, int]:
        return dict(Counter(f.category for f in self.findings).most_common())

    @property
    def score(self) -> int:
        penalty = sum(SEVERITY_WEIGHT[f.severity] for f in self.findings)
        return int(round(100 * math.exp(-penalty / 60)))

    @property
    def grade(self) -> str:
        s = self.score
        grade = "A" if s >= 90 else "B" if s >= 75 else "C" if s >= 55 else "D" if s >= 35 else "F"
        if self.counts()["critical"] and grade in "ABC":
            grade = "D"
        return grade

    def exceeds(self, threshold: str) -> bool:
        if threshold in ("none", "never", ""):
            return False
        limit = SEVERITY_RANK[normalize_severity(threshold)]
        return any(SEVERITY_RANK[f.severity] >= limit for f in self.findings)

    def to_dict(self) -> dict:
        return {
            "tool": {"name": "qa-sentinel", "version": __version__},
            "project": {
                "root": str(self.project.root), "name": self.project.root.name,
                "files_scanned": len(self.project.files),
                "languages": dict(self.project.languages.most_common()),
                "package_managers": sorted(self.project.manifests),
            },
            "started_at": self.started_at,
            "duration_seconds": round(self.duration, 2),
            "summary": {
                "total": len(self.findings), "by_severity": self.counts(), "by_category": self.by_category(),
                "risk_score": self.score, "grade": self.grade, "suppressed": self.suppressed,
            },
            "scanners": [s.to_dict() for s in self.scanners],
            "findings": [f.to_dict() for f in self.findings],
        }


CWE_FAMILY = {
    "CWE-328": "CWE-327", "CWE-916": "CWE-327", "CWE-326": "CWE-327",
    "CWE-676": "CWE-120", "CWE-242": "CWE-120", "CWE-121": "CWE-120", "CWE-787": "CWE-120",
    "CWE-94": "CWE-95", "CWE-77": "CWE-78", "CWE-259": "CWE-798", "CWE-321": "CWE-798",
    "CWE-489": "CWE-215", "CWE-215": "CWE-215", "CWE-1327": "CWE-200", "CWE-605": "CWE-200",
}


def _dedupe_key(f: Finding) -> tuple:
    if f.category == "dependency":
        return ("dep", f.file, f.rule_id, f.snippet)
    if f.file and f.line and f.cwe:
        return ("loc", f.file, f.line, CWE_FAMILY.get(f.cwe, f.cwe))
    return ("raw", f.rule_id, f.file, f.line, f.snippet.strip())


def deduplicate(findings: list[Finding]) -> list[Finding]:
    findings = _merge(findings, _dedupe_key)
    return _merge(findings, lambda f: ("title", f.file, f.line, f.title.lower()) if f.line else ("id", id(f)))


def _merge(findings: list[Finding], key_fn) -> list[Finding]:
    merged: dict[tuple, Finding] = {}
    for f in findings:
        key = key_fn(f)
        cur = merged.get(key)
        if cur is None:
            merged[key] = f
            continue
        keep, other = (f, cur) if SEVERITY_RANK[f.severity] > SEVERITY_RANK[cur.severity] else (cur, f)
        scanners = list(dict.fromkeys(keep.scanner.split(", ") + other.scanner.split(", ")))
        keep.scanner = ", ".join(scanners)
        keep.references = list(dict.fromkeys(keep.references + other.references))
        merged[key] = keep
    return list(merged.values())


def apply_policy(project: Project, findings: list[Finding], min_severity: str) -> tuple[list[Finding], int]:
    cfg = project.config
    overrides = cfg.get("severity_overrides", {})
    ignored = set(cfg.get("ignore", []))
    floor = SEVERITY_RANK[normalize_severity(min_severity, "info")]
    kept, suppressed = [], 0
    for f in findings:
        if f.rule_id in overrides:
            f.severity = normalize_severity(overrides[f.rule_id])
        # External tools (e.g. osv-scanner) walk the tree themselves, so re-apply the project's excludes here.
        excluded = bool(f.file) and project.is_excluded(f.file)
        if excluded or f.rule_id in ignored or f.fingerprint in ignored or SEVERITY_RANK[f.severity] < floor:
            suppressed += 1
            continue
        kept.append(f)
    return kept, suppressed


def select_scanners(project: Project, only: list[str] | None, skip: list[str] | None) -> list[Scanner]:
    skip = set(skip or []) | set(project.config.get("disable", []))
    return [s for s in all_scanners() if (not only or s.name in only) and s.name not in skip]


def _run_one(scanner: Scanner, project: Project) -> ScannerResult:
    start = time.monotonic()
    if not scanner.is_available():
        return ScannerResult(scanner.name, "skipped", f"not installed ({scanner.install_hint})")
    if not scanner.is_applicable(project):
        return ScannerResult(scanner.name, "not_applicable", "no relevant files")
    try:
        findings = scanner.run(project)
        return ScannerResult(scanner.name, "ok", "", time.monotonic() - start, findings)
    except ScannerSkipped as exc:
        return ScannerResult(scanner.name, "skipped", str(exc), time.monotonic() - start)
    except Exception as exc:  # a broken scanner must never abort the whole run
        return ScannerResult(scanner.name, "error", f"{type(exc).__name__}: {exc}"[:400], time.monotonic() - start)


def run_scan(project: Project, only: list[str] | None = None, skip: list[str] | None = None, jobs: int = 4,
             min_severity: str = "info", on_result: Callable[[ScannerResult], None] | None = None) -> Report:
    started = datetime.now(timezone.utc).isoformat(timespec="seconds")
    t0 = time.monotonic()
    scanners = select_scanners(project, only, skip)
    results: list[ScannerResult] = []
    with ThreadPoolExecutor(max_workers=max(1, jobs)) as pool:
        futures = [pool.submit(_run_one, s, project) for s in scanners]
        for fut in futures:
            res = fut.result()
            results.append(res)
            if on_result:
                on_result(res)
    findings = deduplicate([f for r in results for f in r.findings])
    findings, suppressed = apply_policy(project, findings, min_severity)
    findings.sort(key=lambda f: (-SEVERITY_RANK[f.severity], f.category, f.file, f.line))
    return Report(project, findings, results, started, time.monotonic() - t0, suppressed)
