QA Sentinel for Windows (portable, no Python install needed)

WEB INTERFACE (English / Arabic):
  Double-click serve.bat. Your browser opens http://localhost:8000
  Upload a file, a folder or a .zip and click "Scan now".
  Keep the black window open while you use it; close it to stop.

COMMAND LINE:
  Double-click scan.bat to scan the bundled example, or run:
    .\scan.bat "C:\path\to\your\project"

-----------------------------------------------------------------
واجهة الويب (عربي / إنجليزي):
  انقر نقراً مزدوجاً على serve.bat وسيفتح المتصفح على http://localhost:8000
  ارفع ملفاً أو مجلداً أو ملف zip ثم اضغط "افحص الآن".
  اترك النافذة السوداء مفتوحة أثناء الاستخدام، وأغلقها للإيقاف.
