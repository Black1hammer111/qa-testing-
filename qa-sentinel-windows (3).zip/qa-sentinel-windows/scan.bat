@echo off
setlocal
set "HERE=%~dp0"
set "PY="

rem 1) portable Python bundled next to this file (Windows download)
if exist "%HERE%python\python.exe" set "PY=%HERE%python\python.exe"

rem 2) Python launcher "py"
if not defined PY for /f "delims=" %%i in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "PY=%%i"

rem 3) standard install folders
for %%v in (314 313 312 311 310 39) do if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\Python%%v\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python%%v\python.exe"
for %%v in (314 313 312 311 310 39) do if not defined PY if exist "%ProgramFiles%\Python%%v\python.exe" set "PY=%ProgramFiles%\Python%%v\python.exe"
if not defined PY for /d %%d in ("%LOCALAPPDATA%\Programs\Python\Python3*") do if exist "%%d\python.exe" set "PY=%%d\python.exe"
if not defined PY for /d %%d in ("%ProgramFiles%\Python3*") do if exist "%%d\python.exe" set "PY=%%d\python.exe"

rem 4) python on PATH, ignoring the Microsoft Store placeholder
if defined PY goto found
for %%i in (python.exe) do set "CAND=%%~$PATH:i"
if not defined CAND goto found
if not "%CAND:WindowsApps=%"=="%CAND%" goto found
set "PY=%CAND%"
:found

if not defined PY (
  echo Python 3 was not found on this computer.
  echo Install it with:  winget install -e --id Python.Python.3.12
  echo or download the Windows version of QA Sentinel, which includes Python.
  pause
  exit /b 1
)

if "%~1"=="" (
  set "TARGET=%HERE%examples\python-flask-app"
  echo No project given - scanning the bundled example.
  echo To scan your project:  scan.bat C:\folder\of\your\project
  echo.
) else (
  set "TARGET=%~f1"
)

echo Using Python: %PY%
pushd "%HERE%"
"%PY%" -m qa_sentinel scan "%TARGET%" --no-tests
echo.
if exist "%TARGET%\qa-report\report.html" (
  echo Opening report: %TARGET%\qa-report\report.html
  start "" "%TARGET%\qa-report\report.html"
) else (
  echo No report was created. Send a screenshot of the messages above.
)
popd
if "%~1"=="" pause
